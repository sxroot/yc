import React, { createContext, useContext, useEffect, useMemo, useState } from 'react';
import { OrderRecord, PRODUCTS, Product, SAMPLE_ORDERS } from '../data/catalog';

export interface BagLineItem {
  key: string; // `${productId}-${size}`
  productId: number;
  size: string;
  quantity: number;
}

export interface AuthMember {
  name: string;
  email: string;
  preferredSilhouette: string;
  joinedAt: string;
}

interface StoreContextValue {
  products: Product[];
  bag: BagLineItem[];
  bagCount: number;
  bagSubtotal: number;
  promoCode: string;
  discountAmount: number;
  applyPromoCode: (code: string) => { ok: boolean; message: string };
  clearPromoCode: () => void;
  collectorPackaging: boolean;
  setCollectorPackaging: (val: boolean) => void;
  giftNote: string;
  setGiftNote: (note: string) => void;
  addToBag: (productId: number, size: string, quantity?: number, openDrawer?: boolean) => void;
  updateBagQuantity: (key: string, quantity: number) => void;
  updateBagSize: (key: string, newSize: string) => void;
  removeFromBag: (key: string) => void;
  clearBag: () => void;

  wishlistIds: number[];
  toggleWishlist: (productId: number) => void;
  isWishlisted: (productId: number) => boolean;
  clearWishlist: () => void;
  restoreSampleWishlist: () => void;

  orders: OrderRecord[];
  placeOrder: (payload: {
    email: string;
    customerName: string;
    shippingAddress: OrderRecord['shippingAddress'];
    shippingMethod: string;
    shippingCost: number;
    paymentSummary: string;
  }) => OrderRecord;

  member: AuthMember | null;
  loginMember: (email: string, name?: string, silhouette?: string) => void;
  logoutMember: () => void;

  bagDrawerOpen: boolean;
  setBagDrawerOpen: (open: boolean) => void;
  searchDrawerOpen: boolean;
  setSearchDrawerOpen: (open: boolean) => void;
  studioDrawerOpen: boolean;
  setStudioDrawerOpen: (open: boolean) => void;
  sitemapDrawerOpen: boolean;
  setSitemapDrawerOpen: (open: boolean) => void;
  sizeGuideModalCategory: string | null;
  setSizeGuideModalCategory: (category: string | null) => void;

  toastMessage: string;
  showToast: (msg: string) => void;
  dismissToast: () => void;
}

const StoreContext = createContext<StoreContextValue | null>(null);

const STORAGE_BAG = 'yc-phase01-bag';
const STORAGE_WISH = 'yc-phase01-wishlist';
const STORAGE_ORDERS = 'yc-phase01-orders';
const STORAGE_MEMBER = 'yc-phase01-member';

const INITIAL_BAG: BagLineItem[] = [
  { key: '2-L', productId: 2, size: 'L', quantity: 1 },
  { key: '4-M', productId: 4, size: 'M', quantity: 1 },
];

const INITIAL_WISHLIST: number[] = [2, 5, 3];

export function StoreProvider({ children }: { children: React.ReactNode }) {
  const [bag, setBag] = useState<BagLineItem[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_BAG);
      return saved ? JSON.parse(saved) : INITIAL_BAG;
    } catch {
      return INITIAL_BAG;
    }
  });

  const [wishlistIds, setWishlistIds] = useState<number[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_WISH);
      return saved ? JSON.parse(saved) : INITIAL_WISHLIST;
    } catch {
      return INITIAL_WISHLIST;
    }
  });

  const [orders, setOrders] = useState<OrderRecord[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_ORDERS);
      return saved ? JSON.parse(saved) : SAMPLE_ORDERS;
    } catch {
      return SAMPLE_ORDERS;
    }
  });

  const [member, setMember] = useState<AuthMember | null>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_MEMBER);
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  const [promoCode, setPromoCode] = useState('');
  const [collectorPackaging, setCollectorPackaging] = useState(false);
  const [giftNote, setGiftNote] = useState('');

  const [bagDrawerOpen, setBagDrawerOpen] = useState(false);
  const [searchDrawerOpen, setSearchDrawerOpen] = useState(false);
  const [studioDrawerOpen, setStudioDrawerOpen] = useState(false);
  const [sitemapDrawerOpen, setSitemapDrawerOpen] = useState(false);
  const [sizeGuideModalCategory, setSizeGuideModalCategory] = useState<string | null>(null);
  const [toastMessage, setToastMessage] = useState('');

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_BAG, JSON.stringify(bag));
    } catch {
      // ignore storage quota errors
    }
  }, [bag]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_WISH, JSON.stringify(wishlistIds));
    } catch {
      // ignore
    }
  }, [wishlistIds]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_ORDERS, JSON.stringify(orders));
    } catch {
      // ignore
    }
  }, [orders]);

  useEffect(() => {
    try {
      if (member) localStorage.setItem(STORAGE_MEMBER, JSON.stringify(member));
      else localStorage.removeItem(STORAGE_MEMBER);
    } catch {
      // ignore
    }
  }, [member]);

  useEffect(() => {
    if (!toastMessage) return;
    const t = setTimeout(() => setToastMessage(''), 4400);
    return () => clearTimeout(t);
  }, [toastMessage]);

  const showToast = (msg: string) => setToastMessage(msg);
  const dismissToast = () => setToastMessage('');

  const bagCount = useMemo(() => bag.reduce((sum, item) => sum + item.quantity, 0), [bag]);

  const bagSubtotal = useMemo(
    () =>
      bag.reduce((sum, item) => {
        const prod = PRODUCTS.find((p) => p.id === item.productId);
        return sum + (prod ? prod.price * item.quantity : 0);
      }, 0),
    [bag]
  );

  const discountAmount = useMemo(() => {
    const normalized = promoCode.trim().toUpperCase();
    if (!normalized || bagSubtotal === 0) return 0;
    if (normalized === 'YC10' || normalized === 'FIRSTCHOICE') return Math.round(bagSubtotal * 0.1);
    if (normalized === 'INDEPENDENT') return Math.round(bagSubtotal * 0.15);
    return 0;
  }, [promoCode, bagSubtotal]);

  const applyPromoCode = (raw: string) => {
    const code = raw.trim().toUpperCase();
    if (!code) {
      return { ok: false, message: 'Enter a valid studio code.' };
    }
    if (code === 'YC10' || code === 'FIRSTCHOICE') {
      setPromoCode(code);
      showToast(`Code ${code} applied — 10% inner-circle privilege.`);
      return { ok: true, message: `${code} applied (10% off subtotal).` };
    }
    if (code === 'INDEPENDENT') {
      setPromoCode(code);
      showToast('Code INDEPENDENT applied — 15% off your rotation.');
      return { ok: true, message: 'INDEPENDENT applied (15% off subtotal).' };
    }
    if (code === 'FREESHIP') {
      setPromoCode(code);
      showToast('Code FREESHIP applied — complimentary express delivery.');
      return { ok: true, message: 'FREESHIP applied (Free Express Courier).' };
    }
    return { ok: false, message: 'Unrecognized code. Try YC10, INDEPENDENT, or FREESHIP.' };
  };

  const clearPromoCode = () => setPromoCode('');

  const addToBag = (productId: number, size: string, quantity = 1, openDrawer = true) => {
    const product = PRODUCTS.find((p) => p.id === productId);
    if (!product) return;
    const key = `${productId}-${size}`;
    setBag((prev) => {
      const existing = prev.find((line) => line.key === key);
      if (existing) {
        return prev.map((line) =>
          line.key === key ? { ...line, quantity: Math.min(10, line.quantity + quantity) } : line
        );
      }
      return [...prev, { key, productId, size, quantity }];
    });
    if (openDrawer) setBagDrawerOpen(true);
    showToast(`A good choice. ${product.name} (${size}) added to your bag.`);
  };

  const updateBagQuantity = (key: string, quantity: number) => {
    if (quantity <= 0) {
      setBag((prev) => prev.filter((item) => item.key !== key));
      return;
    }
    setBag((prev) =>
      prev.map((item) => (item.key === key ? { ...item, quantity: Math.min(10, quantity) } : item))
    );
  };

  const updateBagSize = (key: string, newSize: string) => {
    setBag((prev) => {
      const target = prev.find((i) => i.key === key);
      if (!target) return prev;
      const newKey = `${target.productId}-${newSize}`;
      if (newKey === key) return prev;
      const duplicate = prev.find((i) => i.key === newKey);
      if (duplicate) {
        return prev
          .filter((i) => i.key !== key)
          .map((i) =>
            i.key === newKey
              ? { ...i, quantity: Math.min(10, i.quantity + target.quantity) }
              : i
          );
      }
      return prev.map((i) => (i.key === key ? { ...i, key: newKey, size: newSize } : i));
    });
  };

  const removeFromBag = (key: string) => {
    setBag((prev) => prev.filter((item) => item.key !== key));
    showToast('Removed from your bag.');
  };

  const clearBag = () => {
    setBag([]);
    setPromoCode('');
    setCollectorPackaging(false);
    setGiftNote('');
  };

  const toggleWishlist = (productId: number) => {
    const prod = PRODUCTS.find((p) => p.id === productId);
    setWishlistIds((prev) => {
      const exists = prev.includes(productId);
      if (exists) {
        showToast(`${prod?.name || 'Piece'} removed from wishlist.`);
        return prev.filter((id) => id !== productId);
      }
      showToast(`${prod?.name || 'Piece'} saved to your wishlist.`);
      return [productId, ...prev];
    });
  };

  const isWishlisted = (productId: number) => wishlistIds.includes(productId);

  const clearWishlist = () => {
    setWishlistIds([]);
    showToast('Wishlist cleared.');
  };

  const restoreSampleWishlist = () => {
    setWishlistIds(INITIAL_WISHLIST);
    showToast('Curated starter pieces restored to wishlist.');
  };

  const placeOrder: StoreContextValue['placeOrder'] = ({
    email,
    customerName,
    shippingAddress,
    shippingMethod,
    shippingCost,
    paymentSummary,
  }) => {
    const randomSuffix = Math.floor(1000 + Math.random() * 8999);
    const orderNumber = `YC-2026-${randomSuffix}`;
    const packagingCost = collectorPackaging ? 8 : 0;
    const effectiveShipping = promoCode.toUpperCase() === 'FREESHIP' ? 0 : shippingCost;
    const total = Math.max(0, bagSubtotal - discountAmount + effectiveShipping + packagingCost);

    const items: OrderRecord['items'] = bag
      .map((line) => {
        const prod = PRODUCTS.find((p) => p.id === line.productId);
        if (!prod) return null;
        return {
          productId: prod.id,
          slug: prod.slug,
          name: prod.name,
          color: prod.color,
          size: line.size,
          price: prod.price,
          quantity: line.quantity,
          image: prod.image,
        };
      })
      .filter((x): x is NonNullable<typeof x> => Boolean(x));

    const newOrder: OrderRecord = {
      orderNumber,
      placedAt: '16 Nov 2026 · Just now',
      estimatedDelivery: shippingMethod.includes('Express') ? '18 – 19 Nov 2026' : '20 – 23 Nov 2026',
      statusStep: 1,
      statusLabel: 'Order Confirmed — Allocated at Studio',
      carrier: shippingMethod.includes('Express') ? 'DHL Express Carbon-Neutral' : 'UPS Studio Tracked',
      trackingCode: `DHL-${randomSuffix}882-YC`,
      email,
      customerName,
      shippingAddress,
      shippingMethod,
      paymentSummary,
      subtotal: bagSubtotal,
      discount: discountAmount,
      shippingCost: effectiveShipping,
      packagingCost,
      total,
      giftNote: giftNote.trim() || undefined,
      items,
      events: [
        {
          date: '16 Nov 2026',
          time: 'Just now',
          location: 'YOUR CHOICE Digital Storefront',
          status: 'Order Confirmed',
          detail: `Order ${orderNumber} verified and assigned to Porto studio fulfilment queue.`,
        },
      ],
    };

    setOrders((prev) => [newOrder, ...prev]);
    clearBag();
    return newOrder;
  };

  const loginMember = (email: string, name?: string, silhouette = 'Architectural Tees & Polos') => {
    const derivedName =
      name?.trim() ||
      email
        .split('@')[0]
        .replace(/[._-]+/g, ' ')
        .replace(/\b\w/g, (c) => c.toUpperCase());
    setMember({
      name: derivedName,
      email,
      preferredSilhouette: silhouette,
      joinedAt: 'November 2026',
    });
    showToast(`Welcome back, ${derivedName}.`);
  };

  const logoutMember = () => {
    setMember(null);
    showToast('Signed out of your YOUR CHOICE account.');
  };

  return (
    <StoreContext.Provider
      value={{
        products: PRODUCTS,
        bag,
        bagCount,
        bagSubtotal,
        promoCode,
        discountAmount,
        applyPromoCode,
        clearPromoCode,
        collectorPackaging,
        setCollectorPackaging,
        giftNote,
        setGiftNote,
        addToBag,
        updateBagQuantity,
        updateBagSize,
        removeFromBag,
        clearBag,
        wishlistIds,
        toggleWishlist,
        isWishlisted,
        clearWishlist,
        restoreSampleWishlist,
        orders,
        placeOrder,
        member,
        loginMember,
        logoutMember,
        bagDrawerOpen,
        setBagDrawerOpen,
        searchDrawerOpen,
        setSearchDrawerOpen,
        studioDrawerOpen,
        setStudioDrawerOpen,
        sitemapDrawerOpen,
        setSitemapDrawerOpen,
        sizeGuideModalCategory,
        setSizeGuideModalCategory,
        toastMessage,
        showToast,
        dismissToast,
      }}
    >
      {children}
    </StoreContext.Provider>
  );
}

export function useStore() {
  const ctx = useContext(StoreContext);
  if (!ctx) throw new Error('useStore must be used inside StoreProvider');
  return ctx;
}
