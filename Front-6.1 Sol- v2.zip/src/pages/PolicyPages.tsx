import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import {
  ArrowRight,
  ArrowUpRight,
  Check,
  CheckCircle2,
  ChevronRight,
  Globe,
  PackageCheck,
  Printer,
  RefreshCw,
  Shield,
  Sliders,
  Truck,
} from 'lucide-react';
import { useStore } from '../context/StoreContext';

/* ============================================================================
   20. SHIPPING & DELIVERY (/shipping-delivery)
   ============================================================================ */
export function ShippingDeliveryPage() {
  const [region, setRegion] = useState<'uk-eu' | 'na' | 'apac' | 'row'>('uk-eu');

  const zoneData = {
    'uk-eu': {
      title: 'United Kingdom & European Union',
      ddp: 'Delivered Duty Paid (DDP) — Zero customs fees upon delivery',
      services: [
        {
          name: 'Standard Studio Tracked',
          carrier: 'DPD / UPS Carbon-Neutral',
          window: '3 – 5 Business Days',
          fee: '$10 (FREE over $150)',
        },
        {
          name: 'DHL Express Air',
          carrier: 'DHL Express GoGreen',
          window: '1 – 2 Business Days',
          fee: '$18 (FREE over $150)',
        },
        {
          name: 'Priority Next-Day Air',
          carrier: 'DHL Priority Before 12:00',
          window: 'Next Business Day',
          fee: '$28',
        },
      ],
    },
    na: {
      title: 'United States & Canada',
      ddp: 'Delivered Duty Paid (DDP) — All US & Canadian import duties pre-cleared',
      services: [
        {
          name: 'Standard Tracked Air',
          carrier: 'UPS Worldwide Expedited',
          window: '4 – 6 Business Days',
          fee: '$12 (FREE over $150)',
        },
        {
          name: 'DHL Express Carbon-Neutral',
          carrier: 'DHL Express Air',
          window: '2 – 3 Business Days',
          fee: '$18 (FREE over $150)',
        },
        {
          name: 'Priority Studio Direct',
          carrier: 'DHL Express Priority',
          window: '1 – 2 Business Days',
          fee: '$28',
        },
      ],
    },
    apac: {
      title: 'Asia-Pacific & Middle East (JP, SG, KR, AE, AU, BD)',
      ddp: 'Delivered Duty Paid (DDP) in major hubs; transparent tax preview at checkout',
      services: [
        {
          name: 'International Tracked',
          carrier: 'DHL / FedEx Economy Air',
          window: '5 – 7 Business Days',
          fee: '$15 (FREE over $150)',
        },
        {
          name: 'DHL Express Worldwide',
          carrier: 'DHL Express GoGreen',
          window: '2 – 4 Business Days',
          fee: '$22 (FREE over $180)',
        },
      ],
    },
    row: {
      title: 'Rest of World',
      ddp: 'Fully insured international air courier with live milestone telemetry',
      services: [
        {
          name: 'DHL Global Express',
          carrier: 'DHL Express',
          window: '3 – 6 Business Days',
          fee: '$25 (FREE over $200)',
        },
      ],
    },
  };

  const currentZone = zoneData[region];

  return (
    <div className="page-shell">
      <nav className="breadcrumb-bar" aria-label="Breadcrumb">
        <Link to="/">Home</Link>
        <ChevronRight size={11} />
        <span>Shipping &amp; Delivery</span>
      </nav>

      <header className="page-masthead">
        <div className="page-masthead-grid">
          <div>
            <p className="eyebrow">
              <Truck size={13} className="text-[var(--blue)]" /> GLOBAL FULFILMENT &amp; LOGISTICS
            </p>
            <h1 className="page-title">
              SHIPPING &amp; <span>DELIVERY.</span>
            </h1>
          </div>
          <p className="page-lead">
            Orders placed before 14:00 UTC Monday–Friday are inspected, steamed, and dispatched the same day from our Porto studio hub. Complimentary Express Delivery on orders above $150.
          </p>
        </div>
      </header>

      <div className="section-pad pt-10 space-y-12">
        {/* Interactive Region Selector */}
        <section className="space-y-5">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <span className="eyebrow">
              <Globe size={13} className="text-[var(--blue)]" /> SELECT DESTINATION ZONE
            </span>
            <div className="category-tabs">
              {[
                { id: 'uk-eu', label: 'UK & Europe' },
                { id: 'na', label: 'North America' },
                { id: 'apac', label: 'Asia-Pacific & UAE' },
                { id: 'row', label: 'Rest of World' },
              ].map((z) => (
                <button
                  key={z.id}
                  type="button"
                  onClick={() => setRegion(z.id as typeof region)}
                  className={region === z.id ? 'active' : ''}
                >
                  {z.label}
                </button>
              ))}
            </div>
          </div>

          <div className="editorial-card space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <h2 className="text-xl font-semibold tracking-tight">{currentZone.title}</h2>
              <span className="mono text-[10px] text-[var(--blue)]">{currentZone.ddp}</span>
            </div>

            <div className="overflow-x-auto border border-[var(--line)]">
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Service Tier</th>
                    <th>Courier Partner</th>
                    <th>Transit Window</th>
                    <th>Rate</th>
                  </tr>
                </thead>
                <tbody>
                  {currentZone.services.map((s) => (
                    <tr key={s.name}>
                      <td className="font-semibold">{s.name}</td>
                      <td>{s.carrier}</td>
                      <td className="font-mono">{s.window}</td>
                      <td className="font-mono font-semibold text-[var(--blue)]">{s.fee}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </section>

        {/* Packaging & Customs Cards */}
        <section className="grid md:grid-cols-3 gap-6">
          {[
            {
              title: '01 / Archival Zero-Plastic Packaging',
              body: 'Every T-shirt, Polo, and Outerwear piece arrives folded in breathable FSC-certified matte garment bags inside tamper-evident recycled kraft mailers or rigid collector boxes.',
            },
            {
              title: '02 / Zero Surprise Customs Duties',
              body: 'We ship Delivered Duty Paid (DDP) across major destinations so your courier never holds your parcel hostage for unexpected clearance charges.',
            },
            {
              title: '03 / Real-Time Telemetry',
              body: 'The moment your parcel leaves our Porto studio table, you receive live scan updates accessible anytime on our Order Tracking page.',
            },
          ].map((card) => (
            <div key={card.title} className="editorial-card space-y-2.5">
              <h3 className="text-base font-semibold">{card.title}</h3>
              <p className="text-xs text-[#596052] leading-relaxed">{card.body}</p>
            </div>
          ))}
        </section>

        <div className="flex flex-wrap gap-3">
          <Link to="/order-tracking" className="button button-blue">
            Track an Existing Shipment <ArrowRight size={16} />
          </Link>
          <Link to="/returns-refunds" className="button button-outline">
            View Returns &amp; Exchanges Policy <ArrowUpRight size={15} />
          </Link>
        </div>
      </div>
    </div>
  );
}

/* ============================================================================
   21. RETURNS & REFUNDS (/returns-refunds)
   ============================================================================ */
export function ReturnsRefundsPage() {
  const [orderNum, setOrderNum] = useState('YC-2026-8841');
  const [actionType, setActionType] = useState<'exchange' | 'refund'>('exchange');
  const [newSize, setNewSize] = useState('M');
  const [rmaCode, setRmaCode] = useState('');

  const handleStartReturn = (e: React.FormEvent) => {
    e.preventDefault();
    setRmaCode(`RMA-YC-${Math.floor(1000 + Math.random() * 8999)}`);
  };

  return (
    <div className="page-shell">
      <nav className="breadcrumb-bar" aria-label="Breadcrumb">
        <Link to="/">Home</Link>
        <ChevronRight size={11} />
        <span>Returns &amp; Refunds</span>
      </nav>

      <header className="page-masthead">
        <div className="page-masthead-grid">
          <div>
            <p className="eyebrow">
              <RefreshCw size={13} className="text-[var(--blue)]" /> 30-DAY CONSIDERED RETURN PROMISE
            </p>
            <h1 className="page-title">
              RETURNS &amp; <span>EXCHANGES.</span>
            </h1>
          </div>
          <p className="page-lead">
            Finding your exact drape should be effortless. Enjoy complimentary instant size exchanges and straightforward 30-day returns on unworn pieces.
          </p>
        </div>
      </header>

      <div className="section-pad pt-10 space-y-12">
        {/* 4-Step Visual Process */}
        <section className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {[
            {
              step: 'STEP 01',
              title: 'Initiate Online in 60s',
              desc: 'Enter your YC-2026 order reference within 30 days of delivery and choose Instant Size Exchange or Refund.',
            },
            {
              step: 'STEP 02',
              title: 'Prepaid Courier Label',
              desc: 'Download your QR code or prepaid DHL/UPS label — zero printer required at participating drop-off points.',
            },
            {
              step: 'STEP 03',
              title: 'Instant Exchange Dispatch',
              desc: 'For size exchanges, your replacement garment ships as soon as the courier scans your return parcel.',
            },
            {
              step: 'STEP 04',
              title: '48-Hour Studio Refund',
              desc: 'Refunds are issued back to your original payment method within 48 business hours of studio inspection.',
            },
          ].map((s) => (
            <div key={s.step} className="editorial-card space-y-2">
              <span className="mono text-[9px] text-[var(--blue)] font-semibold">{s.step}</span>
              <h2 className="text-base font-semibold">{s.title}</h2>
              <p className="text-xs text-[#596052] leading-relaxed">{s.desc}</p>
            </div>
          ))}
        </section>

        {/* Interactive Self-Service Return / Exchange Portal + Eligibility */}
        <div className="grid lg:grid-cols-12 gap-8">
          <div className="lg:col-span-7">
            {rmaCode ? (
              <div className="editorial-card space-y-5">
                <div className="w-11 h-11 bg-[var(--blue)] text-white grid place-items-center">
                  <PackageCheck size={22} />
                </div>
                <span className="mono text-[10px] text-[var(--blue)]">
                  AUTHORIZATION GENERATED · {rmaCode}
                </span>
                <h2 className="text-2xl font-semibold tracking-tight">
                  Your prepaid return label is ready.
                </h2>
                <p className="text-xs text-[#555b4f] leading-relaxed">
                  {actionType === 'exchange'
                    ? `Replacement Size ${newSize} has been reserved for order ${orderNum} and will dispatch upon first courier drop-off scan.`
                    : `Full refund authorization linked to order ${orderNum}. Drop off within 14 days at any DHL ServicePoint.`}
                </p>
                <button
                  type="button"
                  onClick={() => setRmaCode('')}
                  className="button button-outline"
                >
                  Simulate Another Request
                </button>
              </div>
            ) : (
              <form onSubmit={handleStartReturn} className="editorial-card space-y-5">
                <div className="border-b border-[var(--line)] pb-3 flex items-center justify-between">
                  <h2 className="text-lg font-semibold tracking-tight">
                    Self-Service Exchange &amp; Return Portal
                  </h2>
                  <span className="mono text-[9px] text-[#60675a]">INSTANT RMA PREVIEW</span>
                </div>

                <div className="field-group">
                  <label className="field-label" htmlFor="ret-order">
                    Order Number *
                  </label>
                  <input
                    id="ret-order"
                    type="text"
                    required
                    value={orderNum}
                    onChange={(e) => setOrderNum(e.target.value)}
                    className="field-input font-mono uppercase"
                  />
                </div>

                <div className="field-group">
                  <span className="field-label">Select Preferred Resolution</span>
                  <div className="grid sm:grid-cols-2 gap-3">
                    <button
                      type="button"
                      onClick={() => setActionType('exchange')}
                      className={`p-3.5 border text-left text-xs ${
                        actionType === 'exchange'
                          ? 'border-[var(--blue)] bg-[#2349ed0d]'
                          : 'border-[#c8cbc2] bg-[#fafaf7]'
                      }`}
                    >
                      <strong className="block">Complimentary Size Exchange ($0)</strong>
                      <span className="text-[#60675a]">Ships immediately on courier scan</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setActionType('refund')}
                      className={`p-3.5 border text-left text-xs ${
                        actionType === 'refund'
                          ? 'border-[var(--blue)] bg-[#2349ed0d]'
                          : 'border-[#c8cbc2] bg-[#fafaf7]'
                      }`}
                    >
                      <strong className="block">Refund to Original Payment</strong>
                      <span className="text-[#60675a]">Processed within 48h of studio QC</span>
                    </button>
                  </div>
                </div>

                {actionType === 'exchange' && (
                  <div className="field-group">
                    <label className="field-label" htmlFor="ret-size">
                      Replacement Size Requested
                    </label>
                    <select
                      id="ret-size"
                      value={newSize}
                      onChange={(e) => setNewSize(e.target.value)}
                      className="field-select font-mono"
                    >
                      {['XS', 'S', 'M', 'L', 'XL', 'XXL'].map((s) => (
                        <option key={s} value={s}>
                          Size {s}
                        </option>
                      ))}
                    </select>
                  </div>
                )}

                <button type="submit" className="button button-blue w-full">
                  Generate Return Authorization <ArrowRight size={16} />
                </button>
              </form>
            )}
          </div>

          <aside className="lg:col-span-5 editorial-card space-y-4">
            <h3 className="text-base font-semibold border-b border-[var(--line)] pb-2.5">
              Return Eligibility Checklist
            </h3>
            <ul className="space-y-3 text-xs text-[#4b5145]">
              {[
                'Requested within 30 calendar days of confirmed delivery.',
                'Garments must be unworn, unwashed, and free of fragrance or marks.',
                'Original YOUR CHOICE woven micro-tags and studio garment bag included.',
                'Final archive or custom Design Studio editions are eligible for size exchange or store credit.',
              ].map((rule) => (
                <li key={rule} className="flex items-start gap-2.5">
                  <Check size={14} className="text-[var(--blue)] mt-0.5 shrink-0" />
                  <span>{rule}</span>
                </li>
              ))}
            </ul>
          </aside>
        </div>
      </div>
    </div>
  );
}

/* ============================================================================
   22. PRIVACY POLICY (/privacy-policy)
   ============================================================================ */
export function PrivacyPolicyPage() {
  const { showToast } = useStore();
  const [functionalCookies, setFunctionalCookies] = useState(true);
  const [editorialAnalytics, setEditorialAnalytics] = useState(false);

  const sections = [
    {
      id: 'collect',
      title: '01 / Information We Collect',
      body: 'When you browse YOUR CHOICE, curate a wishlist, build a shopping bag, or complete an order, we process only the information required to deliver your experience: contact details (name, email, shipping address), selected garment sizes, and browser session preferences.',
    },
    {
      id: 'usage',
      title: '02 / How We Use Your Data',
      body: 'We use your data exclusively to fulfill studio orders, transmit live courier tracking milestones, recommend accurate garment sizing, and—only where you explicitly opt in—send Inner Circle dispatches about new Vol. 01 releases and Design Studio updates.',
    },
    {
      id: 'storage',
      title: '03 / Local Browser Storage & Security',
      body: 'In this Phase 01 public storefront, your shopping bag, curated wishlist, and demo order history are stored locally in your browser (localStorage) for instantaneous responsiveness without invasive third-party advertising trackers.',
    },
    {
      id: 'sharing',
      title: '04 / Zero Data Brokerage',
      body: 'YOUR CHOICE never sells, rents, or trades client personal data. In live commerce operations, shipping coordinates are shared strictly with encrypted payment processors and carbon-neutral couriers (DHL / UPS) to deliver your parcel.',
    },
    {
      id: 'rights',
      title: '05 / Your Privacy Rights (GDPR / CCPA)',
      body: 'Regardless of your location, you have the right to access, export, correct, or erase your personal data at any time, or withdraw newsletter consent with a single click. Contact privacy@yourchoice.studio for immediate Data Protection Officer assistance.',
    },
  ];

  return (
    <div className="page-shell">
      <nav className="breadcrumb-bar" aria-label="Breadcrumb">
        <Link to="/">Home</Link>
        <ChevronRight size={11} />
        <span>Privacy Policy</span>
      </nav>

      <header className="page-masthead">
        <div className="page-masthead-grid">
          <div>
            <p className="eyebrow">
              <Shield size={13} className="text-[var(--blue)]" /> TRANSPARENT DATA GOVERNANCE · UPDATED NOV 2026
            </p>
            <h1 className="page-title">
              PRIVACY <span>POLICY.</span>
            </h1>
          </div>
          <p className="page-lead">
            Your expression belongs to you — and so does your personal data. Clear, readable commitments with zero hidden ad-network tracking.
          </p>
        </div>
      </header>

      <div className="legal-grid">
        <nav className="legal-toc" aria-label="Privacy policy sections">
          <span className="mono text-[9px] text-[#18191a] font-semibold">CONTENTS</span>
          {sections.map((s) => (
            <a key={s.id} href={`#${s.id}`}>
              {s.title}
            </a>
          ))}
          <a href="#cookie-controls">06 / Cookie Preferences</a>
        </nav>

        <div className="space-y-10 max-w-3xl">
          {sections.map((s) => (
            <section key={s.id} id={s.id} className="space-y-3 border-b border-[var(--line)] pb-8">
              <h2 className="text-xl font-semibold tracking-tight">{s.title}</h2>
              <p className="text-sm text-[#4c5246] leading-relaxed">{s.body}</p>
            </section>
          ))}

          {/* Interactive Cookie & Storage Preferences */}
          <section id="cookie-controls" className="editorial-card space-y-4">
            <div className="flex items-center gap-2">
              <Sliders size={16} className="text-[var(--blue)]" />
              <h2 className="text-lg font-semibold">06 / Interactive Privacy &amp; Cookie Controls</h2>
            </div>

            <div className="space-y-3 text-xs">
              <div className="flex items-center justify-between py-2 border-b border-[#dfe2da]">
                <div>
                  <strong className="block">Essential Storefront Storage (Bag &amp; Session)</strong>
                  <span className="text-[#60675a]">Required to remember items in your Shopping Bag.</span>
                </div>
                <span className="mono text-[10px] text-[var(--blue)]">ALWAYS ACTIVE</span>
              </div>

              <label className="flex items-center justify-between py-2 border-b border-[#dfe2da] cursor-pointer">
                <div>
                  <strong className="block">Fit &amp; Unit Preferences</strong>
                  <span className="text-[#60675a]">Remembers CM/Inches and preferred silhouette block.</span>
                </div>
                <input
                  type="checkbox"
                  checked={functionalCookies}
                  onChange={(e) => setFunctionalCookies(e.target.checked)}
                  className="w-4 h-4 accent-[var(--blue)]"
                />
              </label>

              <label className="flex items-center justify-between py-2 cursor-pointer">
                <div>
                  <strong className="block">Anonymous Storefront Performance Telemetry</strong>
                  <span className="text-[#60675a]">Helps us refine layout speed and accessibility.</span>
                </div>
                <input
                  type="checkbox"
                  checked={editorialAnalytics}
                  onChange={(e) => setEditorialAnalytics(e.target.checked)}
                  className="w-4 h-4 accent-[var(--blue)]"
                />
              </label>
            </div>

            <button
              type="button"
              onClick={() => showToast('Privacy preferences saved for this browser.')}
              className="button button-blue"
            >
              Save Privacy Preferences <CheckCircle2 size={16} />
            </button>
          </section>
        </div>
      </div>
    </div>
  );
}

/* ============================================================================
   23. TERMS & CONDITIONS (/terms-conditions)
   ============================================================================ */
export function TermsConditionsPage() {
  const clauses = [
    {
      id: 'scope',
      title: '01 / Storefront Overview & Acceptance',
      body: 'These Terms & Conditions govern your access to and use of the YOUR CHOICE public digital storefront ("Always The Best Choice · Independent by Design"). By browsing, registering an Inner Circle profile, or simulating an order, you agree to these terms.',
    },
    {
      id: 'products',
      title: '02 / Garment Specifications, Color & Availability',
      body: 'We calibrate studio photography to represent our #2349ed Royal Blue, Obsidian, Warm Chalk, and Stone Olive dye lots as accurately as possible. Because pieces are produced in numbered European studio batches, quantities per size may be capped to prevent resale hoarding.',
    },
    {
      id: 'pricing',
      title: '03 / Pricing, Taxes & Delivered Duty Paid (DDP)',
      body: 'All prices are displayed in USD. Applicable import duties and local VAT/GST for supported DDP destinations are calculated transparently prior to order confirmation. Promotional codes (such as YC10 or INDEPENDENT) cannot be combined retrospectively.',
    },
    {
      id: 'ip',
      title: '04 / Official Logo, Monogram & Intellectual Property',
      body: 'The YOUR CHOICE® wordmark, YC® monogram, official winged circuit-and-network emblem, garment pattern blocks, and editorial photography are the exclusive intellectual property of YOUR CHOICE. Unauthorized reproduction or commercial counterfeiting is strictly prohibited.',
    },
    {
      id: 'studio',
      title: '05 / Design Studio Creator Terms Preview',
      body: 'Creators joining the upcoming YOUR CHOICE Design Studio retain moral authorship of their original artwork applied to our Atelier Blanks while granting YOUR CHOICE a non-exclusive license to manufacture, fulfill, and account creator royalties transparently.',
    },
    {
      id: 'returns-law',
      title: '06 / Returns, Liability & Governing Law',
      body: 'All eligible purchases are backed by our 30-Day Considered Return Promise. Nothing in these terms limits your statutory consumer rights. Governed by the laws of England & Wales.',
    },
  ];

  return (
    <div className="page-shell">
      <nav className="breadcrumb-bar" aria-label="Breadcrumb">
        <Link to="/">Home</Link>
        <ChevronRight size={11} />
        <span>Terms &amp; Conditions</span>
      </nav>

      <header className="page-masthead">
        <div className="page-masthead-grid">
          <div>
            <p className="eyebrow">
              <i /> HOUSE TERMS OF SERVICE · EFFECTIVE NOV 2026
            </p>
            <h1 className="page-title">
              TERMS &amp; <span>CONDITIONS.</span>
            </h1>
          </div>
          <div className="space-y-3">
            <p className="page-lead">
              Plain-language commercial, intellectual property, and client care terms governing the YOUR CHOICE storefront experience.
            </p>
            <button
              type="button"
              onClick={() => window.print()}
              className="button button-outline"
            >
              Print / Save Terms PDF <Printer size={15} />
            </button>
          </div>
        </div>
      </header>

      <div className="legal-grid">
        <nav className="legal-toc" aria-label="Terms sections">
          <span className="mono text-[9px] text-[#18191a] font-semibold">CLAUSES</span>
          {clauses.map((c) => (
            <a key={c.id} href={`#${c.id}`}>
              {c.title}
            </a>
          ))}
        </nav>

        <div className="space-y-10 max-w-3xl">
          {clauses.map((c) => (
            <section key={c.id} id={c.id} className="space-y-3 border-b border-[var(--line)] pb-8">
              <h2 className="text-xl font-semibold tracking-tight">{c.title}</h2>
              <p className="text-sm text-[#4c5246] leading-relaxed">{c.body}</p>
            </section>
          ))}

          <div className="flex flex-wrap gap-3 pt-2">
            <Link to="/privacy-policy" className="button button-outline">
              Read Privacy Policy <ArrowUpRight size={15} />
            </Link>
            <Link to="/contact" className="button button-blue">
              Questions? Contact Legal &amp; Care <ArrowRight size={15} />
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
