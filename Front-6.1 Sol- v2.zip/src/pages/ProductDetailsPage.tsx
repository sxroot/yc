import React, { useEffect, useMemo, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import {
  ArrowRight,
  ArrowUpRight,
  Check,
  ChevronDown,
  ChevronRight,
  Heart,
  Maximize2,
  Minus,
  Plus,
  Ruler,
  ShieldCheck,
  ShoppingBag,
  Sparkles,
  Truck,
  X,
} from 'lucide-react';
import { PRODUCTS, formatPrice } from '../data/catalog';
import { useStore } from '../context/StoreContext';
import { ProductCard } from '../components/ProductCard';

export function ProductDetailsPage() {
  const { slug } = useParams<{ slug?: string }>();
  const navigate = useNavigate();
  const {
    addToBag,
    isWishlisted,
    toggleWishlist,
    setSizeGuideModalCategory,
  } = useStore();

  const product = useMemo(
    () => PRODUCTS.find((p) => p.slug === slug) || PRODUCTS[1],
    [slug]
  );

  const [selectedSize, setSelectedSize] = useState<string>('');
  const [quantity, setQuantity] = useState(1);
  const [activeFrame, setActiveFrame] = useState(0);
  const [zoomOpen, setZoomOpen] = useState(false);
  const [openAccordion, setOpenAccordion] = useState<string>('material');
  const [sizeError, setSizeError] = useState(false);

  useEffect(() => {
    setSelectedSize('');
    setQuantity(1);
    setActiveFrame(0);
    setSizeError(false);
  }, [product.slug]);

  const saved = isWishlisted(product.id);

  const galleryFrames = useMemo(
    () => [
      {
        id: 'front',
        label: '01 / Studio Front',
        src: product.image,
        mode: 'studio' as const,
        transform: 'scale(1)',
      },
      {
        id: 'collar',
        label: '02 / Collar & Badge',
        src: product.image,
        mode: 'studio' as const,
        transform: 'scale(1.62) translateY(15%)',
      },
      {
        id: 'drape',
        label: '03 / Hem & Weave',
        src: product.image,
        mode: 'studio' as const,
        transform: 'scale(1.48) translateY(-13%)',
      },
      {
        id: 'editorial',
        label: '04 / Campaign Context',
        src: product.lifestyleImage,
        mode: 'editorial' as const,
        transform: 'scale(1)',
      },
    ],
    [product]
  );

  const relatedPieces = useMemo(() => {
    const others = PRODUCTS.filter((p) => p.id !== product.id);
    const crossCategory = others.filter((p) => p.category !== product.category).slice(0, 2);
    const sameCategory = others.filter((p) => p.category === product.category).slice(0, 1);
    return [...sameCategory, ...crossCategory].slice(0, 3);
  }, [product]);

  const handleAddToBag = () => {
    if (!selectedSize) {
      setSizeError(true);
      return;
    }
    setSizeError(false);
    addToBag(product.id, selectedSize, quantity, true);
  };

  const handleBuyNow = () => {
    const chosen = selectedSize || (product.sizes.includes('L') ? 'L' : product.sizes[0]);
    addToBag(product.id, chosen, quantity, false);
    navigate('/checkout');
  };

  const isLowStock = selectedSize && product.lowStockSizes?.includes(selectedSize);

  return (
    <div className="page-shell">
      {/* Breadcrumb */}
      <nav className="breadcrumb-bar" aria-label="Breadcrumb">
        <Link to="/">Home</Link>
        <ChevronRight size={11} />
        <Link to="/shop">Shop</Link>
        <ChevronRight size={11} />
        <Link
          to={
            product.category === 'T-Shirts'
              ? '/collections/t-shirts'
              : product.category === 'Polo Shirts'
              ? '/collections/polo-shirts'
              : '/collections/expression-vol-01'
          }
        >
          {product.category}
        </Link>
        <ChevronRight size={11} />
        <span className="text-[#18191a]">{product.name}</span>
      </nav>

      {/* Main PDP Split Grid */}
      <section className="pdp-grid">
        {/* Left: Multi-Frame Gallery */}
        <div className="pdp-gallery-wrap">
          <div className="pdp-thumbs" role="tablist" aria-label="Product gallery views">
            {galleryFrames.map((frame, i) => (
              <button
                key={frame.id}
                type="button"
                role="tab"
                aria-selected={activeFrame === i}
                aria-label={frame.label}
                onClick={() => setActiveFrame(i)}
                className={`pdp-thumb ${activeFrame === i ? 'is-active' : ''}`}
              >
                <img
                  src={frame.src}
                  alt=""
                  className={frame.mode === 'editorial' ? '!object-cover' : ''}
                />
              </button>
            ))}
          </div>

          <div className="space-y-3">
            <div className="pdp-stage group">
              <div className="product-meta">
                <span>
                  {product.code} · {product.gsm}
                </span>
                {product.badge && (
                  <span className="product-badge-pill is-blue">{product.badge}</span>
                )}
              </div>

              <img
                src={galleryFrames[activeFrame].src}
                alt={`${product.name} — ${galleryFrames[activeFrame].label}`}
                style={{ transform: galleryFrames[activeFrame].transform }}
                className={
                  galleryFrames[activeFrame].mode === 'editorial'
                    ? '!w-full !h-full !object-cover'
                    : ''
                }
              />

              <button
                type="button"
                onClick={() => setZoomOpen(true)}
                aria-label="Open full-screen zoom view"
                className="absolute bottom-4 right-4 z-10 px-3 py-2 bg-[#f5f5f1e6] border border-[#18191a20] text-[10px] font-mono inline-flex items-center gap-1.5 hover:bg-[var(--blue)] hover:text-white transition-colors"
              >
                <Maximize2 size={12} /> {galleryFrames[activeFrame].label}
              </button>
            </div>

            {/* Editorial Studio Note Card under Gallery */}
            <div className="editorial-card flex flex-wrap items-center justify-between gap-4">
              <div>
                <span className="mono text-[9px] text-[var(--blue)]">ATELIER DESIGN NOTE</span>
                <p className="text-xs text-[#4b5145] mt-1 max-w-xl leading-relaxed">
                  {product.editorialNote}
                </p>
              </div>
              <span className="mono text-[9px] px-2.5 py-1 border border-[#c6c9c0] bg-[#fafaf7]">
                {product.origin}
              </span>
            </div>
          </div>
        </div>

        {/* Right: Product Info & Purchase Controls */}
        <div className="pdp-info">
          <div className="flex items-center justify-between gap-2">
            <span className="eyebrow">
              <i /> {product.category} · {product.subStyle}
            </span>
            <span className="mono text-[10px] text-[#5c6355]">★ 4.9 · STUDIO VERIFIED</span>
          </div>

          <h1 className="pdp-title">{product.name}</h1>

          <div className="pdp-price-row">
            <span className="pdp-price">{formatPrice(product.price)}</span>
            {product.compareAtPrice && (
              <span className="font-mono text-sm line-through text-[#8a9082]">
                {formatPrice(product.compareAtPrice)}
              </span>
            )}
            <span className="mono text-[9px] text-[#5e6557] ml-auto">
              DUTIES &amp; TAXES INCLUDED (DDP)
            </span>
          </div>

          <p className="text-[13px] leading-relaxed text-[#4b5145] mt-5">
            {product.description}
          </p>

          {/* Colorway Variant Selector */}
          <div className="mt-6">
            <div className="flex items-center justify-between text-xs mb-2.5">
              <span>
                Colorway: <strong>{product.color}</strong>
              </span>
              <span className="mono text-[10px] text-[#60675a]">
                {product.variants.length} EDITION{product.variants.length > 1 ? 'S' : ''}
              </span>
            </div>
            <div className="flex flex-wrap gap-2.5">
              {product.variants.map((v) => {
                const active = v.slug === product.slug;
                return (
                  <Link
                    key={v.slug}
                    to={`/product/${v.slug}`}
                    className={`px-3 py-2 border text-xs inline-flex items-center gap-2 transition-all ${
                      active
                        ? 'border-[var(--blue)] bg-[#2349ed0d] font-semibold'
                        : 'border-[#c8cbc2] bg-[#fafaf7] hover:border-[#18191a]'
                    }`}
                  >
                    <span
                      className="w-3.5 h-3.5 rounded-full border border-black/25"
                      style={{ backgroundColor: v.hex }}
                    />
                    <span>{v.label}</span>
                  </Link>
                );
              })}
            </div>
          </div>

          {/* Size Selector */}
          <fieldset className="size-select">
            <div className="size-select-header">
              <span>
                Select Size:{' '}
                <strong className={sizeError ? 'text-[#b42318]' : ''}>
                  {selectedSize || (sizeError ? 'Please select your size' : `${product.fit} Fit`)}
                </strong>
              </span>
              <button
                type="button"
                onClick={() => setSizeGuideModalCategory(product.category)}
                className="inline-flex items-center gap-1.5 text-[var(--blue)] underline font-medium"
              >
                <Ruler size={13} /> Size Guide &amp; Fit Finder
              </button>
            </div>

            <div className="size-buttons-row">
              {product.sizes.map((sz) => (
                <button
                  key={sz}
                  type="button"
                  aria-pressed={selectedSize === sz}
                  onClick={() => {
                    setSelectedSize(sz);
                    setSizeError(false);
                  }}
                  className={`size-btn ${selectedSize === sz ? 'selected' : ''}`}
                >
                  {sz}
                </button>
              ))}
            </div>

            <div className="mt-2.5 flex items-center justify-between text-[11px]">
              {selectedSize ? (
                isLowStock ? (
                  <span className="text-[#b54708] font-medium">
                    ● Low studio allocation in {selectedSize} — only 2 pieces remaining
                  </span>
                ) : (
                  <span className="text-[#1f6f43] font-medium inline-flex items-center gap-1">
                    <Check size={13} /> Size {selectedSize} in stock — dispatches within 24h
                  </span>
                )
              ) : (
                <span className="text-[#60675a]">{product.modelNote}</span>
              )}
            </div>
          </fieldset>

          {/* Quantity + Primary CTAs */}
          <div className="space-y-3">
            <div className="flex gap-2.5">
              <div className="inline-flex items-center border border-[#c2c8b8] bg-[#fafaf7] px-1">
                <button
                  type="button"
                  aria-label="Decrease quantity"
                  onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                  className="w-9 h-11 grid place-items-center"
                >
                  <Minus size={14} />
                </button>
                <span className="w-8 text-center font-mono text-xs">{quantity}</span>
                <button
                  type="button"
                  aria-label="Increase quantity"
                  onClick={() => setQuantity((q) => Math.min(10, q + 1))}
                  className="w-9 h-11 grid place-items-center"
                >
                  <Plus size={14} />
                </button>
              </div>

              <button
                type="button"
                onClick={handleAddToBag}
                className="button button-blue flex-1"
              >
                <span>
                  {selectedSize
                    ? `Make it yours — Add ${selectedSize} to Bag`
                    : 'Choose size to add to bag'}
                </span>
                <ShoppingBag size={17} />
              </button>

              <button
                type="button"
                onClick={() => toggleWishlist(product.id)}
                aria-label={saved ? 'Remove from wishlist' : 'Save to wishlist'}
                aria-pressed={saved}
                className={`w-12 min-h-[47px] border grid place-items-center transition-colors ${
                  saved
                    ? 'bg-[var(--blue)] text-white border-[var(--blue)]'
                    : 'border-[#c2c8b8] bg-[#fafaf7] hover:border-[#18191a]'
                }`}
              >
                <Heart size={18} fill={saved ? 'currentColor' : 'none'} />
              </button>
            </div>

            <button
              type="button"
              onClick={handleBuyNow}
              className="button button-dark w-full"
            >
              <span>Express Checkout — Buy Now ({formatPrice(product.price * quantity)})</span>
              <ArrowRight size={16} />
            </button>
          </div>

          {/* Trust Micro-Grid */}
          <div className="grid grid-cols-3 gap-2 my-6 py-3.5 px-3 bg-[#eceee8] border border-[var(--line)] text-[10px] font-mono">
            <span className="flex items-center gap-1.5">
              <Truck size={13} className="text-[var(--blue)] shrink-0" /> Free Express $150+
            </span>
            <span className="flex items-center gap-1.5">
              <ShieldCheck size={13} className="text-[var(--blue)] shrink-0" /> 30-Day Returns
            </span>
            <span className="flex items-center gap-1.5">
              <Sparkles size={13} className="text-[var(--blue)] shrink-0" /> GOTS Certified
            </span>
          </div>

          {/* Editorial Accordions */}
          <div>
            {[
              {
                id: 'material',
                title: 'Fabric Architecture & Composition',
                content: (
                  <div className="space-y-2">
                    <p>{product.material}</p>
                    <p className="font-mono text-[10px] text-[#18191a]">
                      WEIGHT: {product.gsm} · ORIGIN: {product.origin}
                    </p>
                  </div>
                ),
              },
              {
                id: 'fit',
                title: 'Silhouette & Fit Guidance',
                content: (
                  <div className="space-y-2">
                    <p>
                      Engineered in our <strong>{product.fit}</strong> studio block. {product.modelNote}
                    </p>
                    <button
                      type="button"
                      onClick={() => setSizeGuideModalCategory(product.category)}
                      className="text-link text-[var(--blue)]"
                    >
                      Compare exact garment measurements <ArrowUpRight size={12} />
                    </button>
                  </div>
                ),
              },
              {
                id: 'care',
                title: 'Garment Care Ritual',
                content: (
                  <ul className="list-disc pl-4 space-y-1">
                    {product.care.map((c) => (
                      <li key={c}>{c}</li>
                    ))}
                  </ul>
                ),
              },
              {
                id: 'shipping',
                title: 'Delivery, Duties & 30-Day Exchanges',
                content: (
                  <p>
                    Dispatched from our Porto studio within 24 hours. Complimentary Express Air shipping on orders above $150. Free instant size exchanges and 30-day considered returns.{' '}
                    <Link to="/shipping-delivery" className="underline text-[var(--blue)]">
                      View full Shipping Policy
                    </Link>
                    .
                  </p>
                ),
              },
            ].map((acc) => {
              const isOpen = openAccordion === acc.id;
              return (
                <div key={acc.id} className="accordion-block">
                  <button
                    type="button"
                    aria-expanded={isOpen}
                    onClick={() => setOpenAccordion(isOpen ? '' : acc.id)}
                    className="accordion-trigger"
                  >
                    <span>{acc.title}</span>
                    <ChevronDown
                      size={15}
                      className={`transition-transform ${isOpen ? 'rotate-180' : ''}`}
                    />
                  </button>
                  {isOpen && <div className="accordion-panel">{acc.content}</div>}
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Complete the Uniform Cross-Sell */}
      <section className="section-pad pt-8 border-t border-[var(--line)]">
        <div className="flex flex-wrap items-end justify-between gap-4 mb-8">
          <div>
            <span className="eyebrow">
              <i /> MODULAR PAIRING
            </span>
            <h2 className="text-3xl font-semibold tracking-tight mt-2">
              Complete the Uniform
            </h2>
          </div>
          <Link to="/shop" className="text-link">
            Explore full catalogue <ArrowUpRight size={14} />
          </Link>
        </div>

        <div className="product-grid">
          {relatedPieces.map((item, idx) => (
            <ProductCard key={item.id} product={item} index={idx} />
          ))}
        </div>
      </section>

      {/* Fullscreen Lightbox Zoom Modal */}
      {zoomOpen && (
        <div
          className="fixed inset-0 z-[190] bg-[#121416ee] backdrop-blur-md flex items-center justify-center p-6"
          onClick={() => setZoomOpen(false)}
          role="dialog"
          aria-modal="true"
          aria-label={`${product.name} zoom gallery`}
        >
          <button
            type="button"
            onClick={() => setZoomOpen(false)}
            aria-label="Close zoom view"
            className="absolute top-6 right-6 w-11 h-11 bg-white/10 text-white grid place-items-center hover:bg-[var(--blue)]"
          >
            <X size={22} />
          </button>
          <img
            src={galleryFrames[activeFrame].src}
            alt={product.name}
            className="max-h-[85svh] max-w-[90vw] object-contain"
            onClick={(e) => e.stopPropagation()}
          />
        </div>
      )}
    </div>
  );
}
