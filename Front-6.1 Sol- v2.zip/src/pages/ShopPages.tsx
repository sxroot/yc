import React, { useMemo, useState } from 'react';
import { Link, useParams, useSearchParams } from 'react-router-dom';
import {
  ArrowDownUp,
  ArrowRight,
  ArrowUpRight,
  ChevronRight,
  Grid2X2,
  Grid3X3,
  LayoutGrid,
  RotateCcw,
  Ruler,
  Search,
  SlidersHorizontal,
  X,
} from 'lucide-react';
import {
  COLLECTIONS,
  CategoryType,
  FAQ_ITEMS,
  PRODUCTS,
  formatPrice,
} from '../data/catalog';
import { ProductCard } from '../components/ProductCard';
import { Reveal } from '../components/BrandMarks';
import { useStore } from '../context/StoreContext';

/* ============================================================================
   1. SHOP / ALL PRODUCTS (/shop)
   ============================================================================ */
export function ShopAllPage() {
  const { setSizeGuideModalCategory } = useStore();
  const [selectedCategory, setSelectedCategory] = useState<'All' | CategoryType>('All');
  const [selectedColor, setSelectedColor] = useState<string>('All');
  const [selectedSize, setSelectedSize] = useState<string>('All');
  const [selectedFit, setSelectedFit] = useState<string>('All');
  const [priceTier, setPriceTier] = useState<'all' | 'under55' | '55to90' | 'over90'>('all');
  const [sortBy, setSortBy] = useState<'featured' | 'newest' | 'bestselling' | 'low' | 'high'>(
    'featured'
  );
  const [searchFilter, setSearchFilter] = useState('');
  const [cols, setCols] = useState<2 | 3 | 4>(3);
  const [showFilters, setShowFilters] = useState(true);

  const colorOptions = useMemo(
    () => [
      { label: 'All', hex: 'transparent' },
      { label: 'Royal Blue', hex: '#2349ed' },
      { label: 'Black / Obsidian', hex: '#16181b' },
      { label: 'Warm Chalk / Bone', hex: '#edece6' },
      { label: 'Stone Olive', hex: '#555b4e' },
      { label: 'Charcoal / Slate', hex: '#393d42' },
      { label: 'Silver', hex: '#b4bac0' },
    ],
    []
  );

  const filteredProducts = useMemo(() => {
    return PRODUCTS.filter((p) => {
      if (selectedCategory !== 'All' && p.category !== selectedCategory) return false;
      if (selectedSize !== 'All' && !p.sizes.includes(selectedSize)) return false;
      if (selectedFit !== 'All' && p.fit !== selectedFit) return false;
      if (priceTier === 'under55' && p.price >= 55) return false;
      if (priceTier === '55to90' && (p.price < 55 || p.price > 90)) return false;
      if (priceTier === 'over90' && p.price <= 90) return false;
      if (selectedColor !== 'All') {
        const c = p.color.toLowerCase();
        if (selectedColor === 'Royal Blue' && !c.includes('blue') && !c.includes('cobalt'))
          return false;
        if (selectedColor === 'Black / Obsidian' && !c.includes('black') && !c.includes('obsidian'))
          return false;
        if (selectedColor === 'Warm Chalk / Bone' && !c.includes('chalk') && !c.includes('bone'))
          return false;
        if (selectedColor === 'Stone Olive' && !c.includes('olive')) return false;
        if (selectedColor === 'Charcoal / Slate' && !c.includes('charcoal') && !c.includes('slate'))
          return false;
        if (selectedColor === 'Silver' && !c.includes('silver')) return false;
      }
      if (searchFilter.trim()) {
        const hay = `${p.name} ${p.color} ${p.category} ${p.subStyle} ${p.gsm}`.toLowerCase();
        if (!hay.includes(searchFilter.trim().toLowerCase())) return false;
      }
      return true;
    }).sort((a, b) => {
      if (sortBy === 'low') return a.price - b.price;
      if (sortBy === 'high') return b.price - a.price;
      if (sortBy === 'bestselling') return a.bestsellerRank - b.bestsellerRank;
      if (sortBy === 'newest') return (b.isNew ? 1 : 0) - (a.isNew ? 1 : 0) || a.position - b.position;
      return a.position - b.position;
    });
  }, [selectedCategory, selectedColor, selectedSize, selectedFit, priceTier, sortBy, searchFilter]);

  const activeFilterCount =
    (selectedCategory !== 'All' ? 1 : 0) +
    (selectedColor !== 'All' ? 1 : 0) +
    (selectedSize !== 'All' ? 1 : 0) +
    (selectedFit !== 'All' ? 1 : 0) +
    (priceTier !== 'all' ? 1 : 0) +
    (searchFilter.trim() ? 1 : 0);

  const resetFilters = () => {
    setSelectedCategory('All');
    setSelectedColor('All');
    setSelectedSize('All');
    setSelectedFit('All');
    setPriceTier('all');
    setSearchFilter('');
  };

  return (
    <div className="page-shell">
      <nav className="breadcrumb-bar" aria-label="Breadcrumb">
        <Link to="/">Home</Link>
        <ChevronRight size={11} />
        <span>Shop / All Products</span>
      </nav>

      <header className="page-masthead">
        <div className="page-masthead-grid">
          <div>
            <p className="eyebrow">
              <i /> 01 / COMPLETE CATALOGUE — VOL. 01
            </p>
            <h1 className="page-title">
              ALL PIECES.
              <br />
              <span>YOUR ROTATION.</span>
            </h1>
          </div>
          <div className="space-y-4">
            <p className="page-lead">
              Explore all {PRODUCTS.length} architectural essentials across heavyweight organic T-shirts, modern piqué &amp; knit polo shirts, loopback fleece, and technical outerwear.
            </p>
            <div className="flex flex-wrap gap-2">
              <Link
                to="/collections/t-shirts"
                className="px-3.5 py-2 border border-[#c7cac1] bg-[#fafaf7] text-xs font-medium hover:border-[var(--blue)] hover:text-[var(--blue)] inline-flex items-center gap-2"
              >
                T-Shirt Collection <ArrowUpRight size={13} />
              </Link>
              <Link
                to="/collections/polo-shirts"
                className="px-3.5 py-2 border border-[#c7cac1] bg-[#fafaf7] text-xs font-medium hover:border-[var(--blue)] hover:text-[var(--blue)] inline-flex items-center gap-2"
              >
                Polo Shirt Collection <ArrowUpRight size={13} />
              </Link>
              <Link
                to="/collections/expression-vol-01"
                className="px-3.5 py-2 border border-[#c7cac1] bg-[#fafaf7] text-xs font-medium hover:border-[var(--blue)] hover:text-[var(--blue)] inline-flex items-center gap-2"
              >
                Expression Vol. 01 <ArrowUpRight size={13} />
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Top Toolbar */}
      <div className="section-pad pt-6">
        <div className="collection-toolbar !mb-0">
          <div className="flex flex-wrap items-center gap-3">
            <button
              type="button"
              onClick={() => setShowFilters((v) => !v)}
              className="px-3.5 py-2 border border-[#18191a33] text-xs font-medium inline-flex items-center gap-2 bg-[#fafaf7]"
            >
              <SlidersHorizontal size={13} />
              {showFilters ? 'Hide Filters' : 'Show Filters'}
              {activeFilterCount > 0 && (
                <span className="px-1.5 py-0.5 bg-[var(--blue)] text-white font-mono text-[9px]">
                  {activeFilterCount}
                </span>
              )}
            </button>

            <div className="category-tabs">
              {(['All', 'T-Shirts', 'Polo Shirts', 'Essentials', 'Outerwear'] as const).map(
                (cat) => {
                  const count =
                    cat === 'All'
                      ? PRODUCTS.length
                      : PRODUCTS.filter((p) => p.category === cat).length;
                  return (
                    <button
                      key={cat}
                      type="button"
                      onClick={() => setSelectedCategory(cat)}
                      className={selectedCategory === cat ? 'active' : ''}
                    >
                      {cat} <sup>{String(count).padStart(2, '0')}</sup>
                    </button>
                  );
                }
              )}
            </div>
          </div>

          <div className="flex items-center gap-4">
            <span className="mono text-[10px] text-[#60675a]">
              {filteredProducts.length} PIECES
            </span>

            <label className="sort-label border border-[#cfd2c9] px-3 py-1.5 bg-[#fafaf7]">
              <ArrowDownUp size={13} />
              <select
                aria-label="Sort catalogue"
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as typeof sortBy)}
              >
                <option value="featured">Sort: Featured</option>
                <option value="bestselling">Sort: Bestselling</option>
                <option value="newest">Sort: New Arrivals</option>
                <option value="low">Price: Low to High</option>
                <option value="high">Price: High to Low</option>
              </select>
            </label>

            <div className="hidden md:inline-flex border border-[#cfd2c9] bg-[#fafaf7]">
              {[
                { c: 2 as const, icon: Grid2X2, label: '2 column editorial view' },
                { c: 3 as const, icon: Grid3X3, label: '3 column studio view' },
                { c: 4 as const, icon: LayoutGrid, label: '4 column archive view' },
              ].map(({ c, icon: Icon, label }) => (
                <button
                  key={c}
                  type="button"
                  aria-label={label}
                  onClick={() => setCols(c)}
                  className={`w-8 h-8 grid place-items-center ${
                    cols === c ? 'bg-[#18191a] text-white' : 'text-[#60675a]'
                  }`}
                >
                  <Icon size={14} />
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Main Workspace: Filter Sidebar + Grid */}
      <div className={`shop-workspace ${showFilters ? '' : 'no-sidebar'}`}>
        {showFilters && (
          <aside className="filter-panel" aria-label="Product filters">
            <div className="filter-group">
              <div className="filter-heading">
                <span>Quick Keyword</span>
                {activeFilterCount > 0 && (
                  <button
                    type="button"
                    onClick={resetFilters}
                    className="text-[var(--blue)] inline-flex items-center gap-1"
                  >
                    <RotateCcw size={10} /> Reset
                  </button>
                )}
              </div>
              <div className="flex items-center gap-2 border border-[#c8cbc2] bg-[#fafaf7] px-2.5 py-1.5">
                <Search size={13} className="text-[#6b7064]" />
                <input
                  type="search"
                  value={searchFilter}
                  onChange={(e) => setSearchFilter(e.target.value)}
                  placeholder="Filter fabric, color..."
                  className="text-xs w-full bg-transparent outline-none"
                />
              </div>
            </div>

            <div className="filter-group">
              <div className="filter-heading">
                <span>Colorway</span>
              </div>
              <div className="filter-list">
                {colorOptions.map((c) => (
                  <button
                    key={c.label}
                    type="button"
                    onClick={() => setSelectedColor(c.label)}
                    className={`filter-option ${selectedColor === c.label ? 'is-selected' : ''}`}
                  >
                    <span className="inline-flex items-center gap-2.5">
                      {c.label !== 'All' && (
                        <span
                          className="w-3 h-3 rounded-full border border-black/20"
                          style={{ backgroundColor: c.hex }}
                        />
                      )}
                      {c.label}
                    </span>
                    {selectedColor === c.label && <span>●</span>}
                  </button>
                ))}
              </div>
            </div>

            <div className="filter-group">
              <div className="filter-heading">
                <span>Size</span>
                <button
                  type="button"
                  onClick={() => setSizeGuideModalCategory('t-shirts')}
                  className="underline text-[var(--blue)]"
                >
                  Size Guide
                </button>
              </div>
              <div className="size-chip-grid">
                {['All', 'XS', 'S', 'M', 'L', 'XL', 'XXL'].map((sz) => (
                  <button
                    key={sz}
                    type="button"
                    onClick={() => setSelectedSize(sz)}
                    className={`size-chip ${selectedSize === sz ? 'is-selected' : ''} ${
                      sz === 'All' ? 'col-span-3' : ''
                    }`}
                  >
                    {sz === 'All' ? 'ALL SIZES' : sz}
                  </button>
                ))}
              </div>
            </div>

            <div className="filter-group">
              <div className="filter-heading">
                <span>Silhouette Fit</span>
              </div>
              <div className="filter-list">
                {['All', 'Oversized', 'Boxy', 'Structured', 'Relaxed'].map((fit) => (
                  <button
                    key={fit}
                    type="button"
                    onClick={() => setSelectedFit(fit)}
                    className={`filter-option ${selectedFit === fit ? 'is-selected' : ''}`}
                  >
                    <span>{fit === 'All' ? 'All Silhouettes' : `${fit} Block`}</span>
                    {selectedFit === fit && <span>●</span>}
                  </button>
                ))}
              </div>
            </div>

            <div className="filter-group">
              <div className="filter-heading">
                <span>Price Range</span>
              </div>
              <div className="filter-list">
                {[
                  { id: 'all', label: 'All Prices' },
                  { id: 'under55', label: 'Under $55 (Tees)' },
                  { id: '55to90', label: '$55 – $90 (Polos & Fleece)' },
                  { id: 'over90', label: 'Over $90 (Outerwear)' },
                ].map((tier) => (
                  <button
                    key={tier.id}
                    type="button"
                    onClick={() => setPriceTier(tier.id as typeof priceTier)}
                    className={`filter-option ${priceTier === tier.id ? 'is-selected' : ''}`}
                  >
                    <span>{tier.label}</span>
                    {priceTier === tier.id && <span>●</span>}
                  </button>
                ))}
              </div>
            </div>
          </aside>
        )}

        <div>
          {/* Active Filter Pills */}
          {activeFilterCount > 0 && (
            <div className="flex flex-wrap items-center gap-2 mb-5">
              {selectedCategory !== 'All' && (
                <button
                  type="button"
                  onClick={() => setSelectedCategory('All')}
                  className="px-3 py-1 bg-[#18191a] text-white text-[11px] inline-flex items-center gap-1.5"
                >
                  {selectedCategory} <X size={11} />
                </button>
              )}
              {selectedColor !== 'All' && (
                <button
                  type="button"
                  onClick={() => setSelectedColor('All')}
                  className="px-3 py-1 bg-[#18191a] text-white text-[11px] inline-flex items-center gap-1.5"
                >
                  {selectedColor} <X size={11} />
                </button>
              )}
              {selectedSize !== 'All' && (
                <button
                  type="button"
                  onClick={() => setSelectedSize('All')}
                  className="px-3 py-1 bg-[#18191a] text-white text-[11px] inline-flex items-center gap-1.5"
                >
                  Size {selectedSize} <X size={11} />
                </button>
              )}
              {selectedFit !== 'All' && (
                <button
                  type="button"
                  onClick={() => setSelectedFit('All')}
                  className="px-3 py-1 bg-[#18191a] text-white text-[11px] inline-flex items-center gap-1.5"
                >
                  {selectedFit} <X size={11} />
                </button>
              )}
              <button type="button" onClick={resetFilters} className="text-link ml-2">
                Clear all
              </button>
            </div>
          )}

          {filteredProducts.length === 0 ? (
            <div className="editorial-card text-center py-16 space-y-4">
              <p className="mono text-xs text-[var(--blue)]">0 MATCHES IN CURRENT FILTER SET</p>
              <h2 className="text-2xl font-semibold tracking-tight">
                No pieces match that exact combination.
              </h2>
              <p className="text-xs text-[#60675a] max-w-md mx-auto">
                Reset one or more refinements to explore our full range of 310 GSM T-shirts, piqué polos, and outerwear.
              </p>
              <button type="button" onClick={resetFilters} className="button button-blue">
                Reset all filters <RotateCcw size={15} />
              </button>
            </div>
          ) : (
            <div
              className={`product-grid ${
                cols === 2 ? 'cols-2' : cols === 4 ? 'cols-4' : ''
              }`}
            >
              {filteredProducts.map((product, idx) => (
                <ProductCard key={product.id} product={product} index={idx} />
              ))}
            </div>
          )}

          {/* Editorial Fit Callout Strip */}
          <div className="mt-14 editorial-card is-dark flex flex-wrap items-center justify-between gap-6">
            <div className="space-y-2 max-w-xl">
              <span className="eyebrow text-[#8ea4ff]">
                <Ruler size={13} /> PRECISION SILHOUETTE SYSTEM
              </span>
              <h3 className="display-condensed text-4xl">
                UNSURE BETWEEN OVERSIZED TEE OR STRUCTURED POLO?
              </h3>
              <p className="text-xs text-[#b7bcc4] leading-relaxed">
                Compare exact chest, shoulder, and garment length measurements in CM or Inches — or calculate your recommended YOUR CHOICE size in seconds.
              </p>
            </div>
            <button
              type="button"
              onClick={() => setSizeGuideModalCategory('t-shirts')}
              className="button button-blue"
            >
              Launch Fit Finder <ArrowUpRight size={17} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ============================================================================
   2. T-SHIRT COLLECTION (/collections/t-shirts)
   ============================================================================ */
export function TShirtCollectionPage() {
  const { setSizeGuideModalCategory } = useStore();
  const [subStyle, setSubStyle] = useState('All Tees');
  const [selectedSize, setSelectedSize] = useState('All');
  const [sortBy, setSortBy] = useState<'featured' | 'low' | 'high'>('featured');

  const tees = useMemo(() => {
    return PRODUCTS.filter((p) => p.category === 'T-Shirts')
      .filter((p) => (subStyle === 'All Tees' ? true : p.subStyle === subStyle))
      .filter((p) => (selectedSize === 'All' ? true : p.sizes.includes(selectedSize)))
      .sort((a, b) =>
        sortBy === 'low' ? a.price - b.price : sortBy === 'high' ? b.price - a.price : a.position - b.position
      );
  }, [subStyle, selectedSize, sortBy]);

  return (
    <div className="page-shell">
      <section className="campaign-banner">
        <img
          src="/images/collection-tees-hero.webp"
          alt="YOUR CHOICE Architectural T-Shirt Collection editorial lookbook"
        />
        <div className="campaign-banner-scrim" />
        <div className="campaign-banner-copy">
          <span className="eyebrow text-[#9db0ff]">
            <i /> CATEGORY 01 / ARCHITECTURAL JERSEY
          </span>
          <h1>
            THE T-SHIRT
            <br />
            <span>COLLECTION.</span>
          </h1>
          <p>
            Heavyweight 295–320 GSM GOTS organic jersey engineered with high-recovery ribbed necklines, dropped shoulder geometry, and zero-shrinkage enzyme washes.
          </p>
          <div className="flex flex-wrap gap-3 mt-6">
            <button
              type="button"
              onClick={() => setSizeGuideModalCategory('t-shirts')}
              className="button button-blue"
            >
              T-Shirt Size &amp; Fit Guide <Ruler size={16} />
            </button>
            <Link to="/collections/polo-shirts" className="button button-ghost-light">
              Explore Polo Shirts <ArrowRight size={16} />
            </Link>
          </div>
        </div>
      </section>

      <div className="spec-ribbon">
        {[
          { label: 'FABRIC WEIGHT', val: '295 – 320 GSM Organic Cotton' },
          { label: 'NECKLINE ARCHITECTURE', val: '28mm Crew & 34mm Mock-Rib' },
          { label: 'FINISH', val: 'Bio-Polished & Pre-Shrunk' },
          { label: 'ORIGIN', val: 'Knitted & Cut in Barcelos, PT' },
        ].map((s) => (
          <div className="spec-ribbon-cell" key={s.label}>
            <span className="mono text-[9px] text-[#697062]">{s.label}</span>
            <strong>{s.val}</strong>
          </div>
        ))}
      </div>

      <div className="section-pad pt-10">
        <div className="collection-toolbar">
          <div className="category-tabs" aria-label="Filter T-Shirt silhouette">
            {['All Tees', 'Heavyweight Boxy', 'Mock-Neck', 'Oversized', 'Long-Sleeve'].map(
              (style) => (
                <button
                  key={style}
                  type="button"
                  onClick={() => setSubStyle(style)}
                  className={subStyle === style ? 'active' : ''}
                >
                  {style}
                </button>
              )
            )}
          </div>

          <div className="flex flex-wrap items-center gap-4">
            <div className="inline-flex items-center gap-1.5">
              <span className="mono text-[9px] text-[#60675a]">SIZE:</span>
              {['All', 'S', 'M', 'L', 'XL'].map((sz) => (
                <button
                  key={sz}
                  type="button"
                  onClick={() => setSelectedSize(sz)}
                  className={`px-2 py-1 text-[10px] font-mono border ${
                    selectedSize === sz
                      ? 'bg-[#18191a] text-white border-[#18191a]'
                      : 'border-[#cccFC7]'
                  }`}
                >
                  {sz}
                </button>
              ))}
            </div>

            <label className="sort-label">
              <ArrowDownUp size={13} />
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as typeof sortBy)}
                aria-label="Sort T-shirts"
              >
                <option value="featured">Featured</option>
                <option value="low">Price: Low to High</option>
                <option value="high">Price: High to Low</option>
              </select>
            </label>
          </div>
        </div>

        <div className="product-grid">
          {tees.map((product, idx) => (
            <ProductCard key={product.id} product={product} index={idx} />
          ))}
        </div>

        {/* Silhouette Block Comparison */}
        <Reveal className="mt-16 grid md:grid-cols-3 gap-5">
          {[
            {
              code: 'BLOCK 01',
              title: 'Signature Oversized',
              desc: 'Generous chest volume, dropped shoulder seam, and clean full-length drape. Featured on our Signature Blue Tee.',
            },
            {
              code: 'BLOCK 02',
              title: '320 GSM Boxy Crop',
              desc: 'Wide architectural shoulder paired with a slightly shorter torso that hits cleanly at the belt line.',
            },
            {
              code: 'BLOCK 03',
              title: 'Interlock Mock-Neck',
              desc: 'Elevated 34mm collar stance crafted from double-knit interlock to frame tailored outerwear and zip hoodies.',
            },
          ].map((b) => (
            <div key={b.code} className="editorial-card space-y-2.5">
              <span className="mono text-[9px] text-[var(--blue)]">{b.code}</span>
              <h3 className="text-lg font-semibold tracking-tight">{b.title}</h3>
              <p className="text-xs text-[#60675a] leading-relaxed">{b.desc}</p>
            </div>
          ))}
        </Reveal>
      </div>
    </div>
  );
}

/* ============================================================================
   3. POLO SHIRT COLLECTION (/collections/polo-shirts)
   ============================================================================ */
export function PoloCollectionPage() {
  const { setSizeGuideModalCategory } = useStore();
  const [subStyle, setSubStyle] = useState('All Polos');
  const [sortBy, setSortBy] = useState<'featured' | 'low' | 'high'>('featured');

  const polos = useMemo(() => {
    return PRODUCTS.filter((p) => p.category === 'Polo Shirts')
      .filter((p) => (subStyle === 'All Polos' ? true : p.subStyle === subStyle))
      .sort((a, b) =>
        sortBy === 'low' ? a.price - b.price : sortBy === 'high' ? b.price - a.price : a.position - b.position
      );
  }, [subStyle, sortBy]);

  return (
    <div className="page-shell">
      <section className="campaign-banner">
        <img
          src="/images/collection-polos-hero.webp"
          alt="YOUR CHOICE Modern Polo Shirt Collection editorial campaign"
        />
        <div className="campaign-banner-scrim" />
        <div className="campaign-banner-copy">
          <span className="eyebrow text-[#9db0ff]">
            <i /> CATEGORY 02 / ELEVATED KNIT &amp; PIQUÉ
          </span>
          <h1>
            POLO SHIRT
            <br />
            <span>COLLECTION.</span>
          </h1>
          <p>
            Sharp zero-curl collars, concealed horn plackets, 14-gauge fine Milano knits, and brushed Excella half-zips — recalibrated for contemporary independent dress.
          </p>
          <div className="flex flex-wrap gap-3 mt-6">
            <button
              type="button"
              onClick={() => setSizeGuideModalCategory('polo-shirts')}
              className="button button-blue"
            >
              Polo Size &amp; Fit Guide <Ruler size={16} />
            </button>
            <Link to="/collections/t-shirts" className="button button-ghost-light">
              Explore T-Shirts <ArrowRight size={16} />
            </Link>
          </div>
        </div>
      </section>

      <div className="spec-ribbon">
        {[
          { label: 'TEXTILES', val: 'Double Piqué, 14G Knit & Merino' },
          { label: 'COLLAR ENGINEERING', val: 'High-Density No-Curl Rib' },
          { label: 'PLACKETS', val: 'Concealed Horn, Open Johnny & Zip' },
          { label: 'SILHOUETTE', val: 'Structured Modern Untucked Cut' },
        ].map((s) => (
          <div className="spec-ribbon-cell" key={s.label}>
            <span className="mono text-[9px] text-[#697062]">{s.label}</span>
            <strong>{s.val}</strong>
          </div>
        ))}
      </div>

      <div className="section-pad pt-10">
        <div className="collection-toolbar">
          <div className="category-tabs" aria-label="Filter Polo silhouette">
            {[
              'All Polos',
              'Heavy Piqué',
              'Johnny Open-Collar',
              'Half-Zip Knit',
              'Long-Sleeve Rugby',
            ].map((style) => (
              <button
                key={style}
                type="button"
                onClick={() => setSubStyle(style)}
                className={subStyle === style ? 'active' : ''}
              >
                {style}
              </button>
            ))}
          </div>

          <label className="sort-label">
            <ArrowDownUp size={13} />
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as typeof sortBy)}
              aria-label="Sort Polo shirts"
            >
              <option value="featured">Featured</option>
              <option value="low">Price: Low to High</option>
              <option value="high">Price: High to Low</option>
            </select>
          </label>
        </div>

        <div className="product-grid">
          {polos.map((product, idx) => (
            <ProductCard key={product.id} product={product} index={idx} />
          ))}
        </div>

        {/* Editorial Craftsmanship Story */}
        <Reveal className="mt-16 grid lg:grid-cols-2 gap-8 items-center editorial-card is-dark">
          <div className="space-y-4">
            <span className="eyebrow text-[var(--cyan)]">
              <i /> ATELIER NOTE — THE COLLAR STANDARD
            </span>
            <h2 className="display-condensed text-5xl">
              TAILORED PRESENCE.
              <br />
              EFFORTLESS COMFORT.
            </h2>
            <p className="text-xs text-[#c2c7cf] leading-relaxed">
              Every YOUR CHOICE polo collar is knitted separately with double-ply tension threads along the outer edge so the points frame your jawline cleanly all day — under a structured blazer or worn solo.
            </p>
            <Link to="/product/atelier-pique-polo" className="button button-blue">
              Inspect Atelier Piqué Polo <ArrowUpRight size={17} />
            </Link>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-[#1d2128] p-4 border border-white/10">
              <img
                src="/images/polo-black.webp"
                alt="Atelier Piqué Knit Polo"
                className="h-44 w-full object-contain"
              />
              <span className="mono text-[9px] text-[#9aa2ae] block mt-2">
                01 / CONCEALED PLACKET PIQUÉ
              </span>
            </div>
            <div className="bg-[#1d2128] p-4 border border-white/10">
              <img
                src="/images/polo-blue.webp"
                alt="Royal Tipped Johnny Polo"
                className="h-44 w-full object-contain"
              />
              <span className="mono text-[9px] text-[#9aa2ae] block mt-2">
                02 / 14-GAUGE JOHNNY COLLAR
              </span>
            </div>
          </div>
        </Reveal>
      </div>
    </div>
  );
}

/* ============================================================================
   4. COLLECTION DETAILS (/collections/:slug & /collections)
   ============================================================================ */
export function CollectionDetailsPage() {
  const { slug } = useParams<{ slug?: string }>();
  const activeCollection =
    COLLECTIONS.find((c) => c.slug === slug) || COLLECTIONS[0];

  const capsuleProducts = useMemo(
    () =>
      activeCollection.featuredSlugs
        .map((s) => PRODUCTS.find((p) => p.slug === s))
        .filter((x): x is NonNullable<typeof x> => Boolean(x)),
    [activeCollection]
  );

  const otherCollections = COLLECTIONS.filter((c) => c.slug !== activeCollection.slug);

  return (
    <div className="page-shell">
      {/* Chapter Switcher Strip */}
      <div className="bg-[#eceee8] border-b border-[var(--line)] px-[5.1%] py-3 flex flex-wrap items-center justify-between gap-3">
        <span className="mono text-[9px] text-[#5e6457]">CAPSULE ARCHIVE CHAPTERS:</span>
        <div className="flex flex-wrap gap-2">
          {COLLECTIONS.map((col) => (
            <Link
              key={col.slug}
              to={`/collections/${col.slug}`}
              className={`px-3 py-1 text-[10px] font-mono border transition-colors ${
                col.slug === activeCollection.slug
                  ? 'bg-[var(--blue)] text-white border-[var(--blue)]'
                  : 'border-[#c6c9c0] bg-[#fafaf7] hover:border-[#18191a]'
              }`}
            >
              {col.shortTitle}
            </Link>
          ))}
        </div>
      </div>

      {/* Campaign Hero */}
      <section className="campaign-banner">
        <img src={activeCollection.heroImage} alt={activeCollection.title} />
        <div className="campaign-banner-scrim" />
        <div className="campaign-banner-copy">
          <span className="eyebrow text-[#9db0ff]">
            <i /> {activeCollection.code} · {activeCollection.releaseDate}
          </span>
          <h1>{activeCollection.title}</h1>
          <p>{activeCollection.subtitle}</p>
          <div className="mt-5 inline-flex items-center gap-3 px-3.5 py-1.5 bg-white/10 backdrop-blur-sm border border-white/20 font-mono text-[10px]">
            <span>{activeCollection.accentLabel}</span>
          </div>
        </div>
      </section>

      {/* Spec Ribbon */}
      <div className="spec-ribbon">
        {activeCollection.specs.map((s) => (
          <div className="spec-ribbon-cell" key={s.label}>
            <span className="mono text-[9px] text-[#697062]">{s.label}</span>
            <strong>{s.value}</strong>
          </div>
        ))}
      </div>

      {/* Editorial Essay + Curatorial Notes */}
      <section className="section-pad py-14 border-b border-[var(--line)] grid lg:grid-cols-12 gap-10 items-start">
        <div className="lg:col-span-5 space-y-3">
          <span className="eyebrow">
            <i /> CURATORIAL MANIFESTO
          </span>
          <h2 className="display-condensed text-5xl">
            DESIGNED AS A MODULAR SYSTEM, NOT ISOLATED GARMENTS.
          </h2>
          <p className="mono text-[10px] text-[#60675a] pt-2">
            {activeCollection.pieceCountLabel} · VOL. 01 EDITION
          </p>
        </div>
        <div className="lg:col-span-7 space-y-4 text-sm leading-relaxed text-[#464b41]">
          <p className="font-medium text-[#18191a] text-base">{activeCollection.description}</p>
          {activeCollection.essay.map((paragraph, i) => (
            <p key={i}>{paragraph}</p>
          ))}
        </div>
      </section>

      {/* Capsule Pieces Grid */}
      <section className="section-pad pt-12">
        <div className="flex flex-wrap items-end justify-between gap-4 mb-8">
          <div>
            <span className="eyebrow">
              <i /> CAPSULE EDITION PIECES
            </span>
            <h2 className="text-3xl font-semibold tracking-tight mt-2">
              Shop {activeCollection.title} ({capsuleProducts.length})
            </h2>
          </div>
          <Link to="/shop" className="text-link">
            Browse full 15-piece catalogue <ArrowUpRight size={14} />
          </Link>
        </div>

        <div className="product-grid">
          {capsuleProducts.map((prod, idx) => (
            <ProductCard key={prod.id} product={prod} index={idx} />
          ))}
        </div>
      </section>

      {/* Explore Other Collections */}
      <section className="section-pad pt-16">
        <div className="border-t border-[var(--line)] pt-12">
          <span className="eyebrow mb-6">
            <i /> CONTINUE EXPLORING CHAPTERS
          </span>
          <div className="grid md:grid-cols-3 gap-5">
            {otherCollections.map((col) => (
              <Link
                key={col.slug}
                to={`/collections/${col.slug}`}
                className="group relative overflow-hidden bg-[#141619] text-white min-h-[250px] p-6 flex flex-col justify-end"
              >
                <img
                  src={col.heroImage}
                  alt={col.title}
                  className="absolute inset-0 w-full h-full object-cover opacity-55 group-hover:scale-105 transition-transform duration-700"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/35 to-transparent" />
                <div className="relative z-10">
                  <span className="mono text-[9px] text-[#9eb0ff]">{col.code}</span>
                  <h3 className="display-condensed text-3xl mt-1 flex items-center justify-between">
                    <span>{col.shortTitle}</span>
                    <ArrowUpRight size={20} />
                  </h3>
                  <p className="text-xs text-[#d0d4dc] mt-1 line-clamp-2">{col.subtitle}</p>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}

/* ============================================================================
   6. SEARCH RESULTS (/search)
   ============================================================================ */
export function SearchResultsPage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const initialQ = searchParams.get('q') || '';
  const [query, setQuery] = useState(initialQ);
  const [tab, setTab] = useState<'all' | 'products' | 'collections' | 'help'>('all');
  const [categoryFilter, setCategoryFilter] = useState<'All' | CategoryType>('All');
  const [sortBy, setSortBy] = useState<'relevance' | 'low' | 'high'>('relevance');

  const qNorm = query.trim().toLowerCase();

  const matchedProducts = useMemo(() => {
    return PRODUCTS.filter((p) => {
      if (categoryFilter !== 'All' && p.category !== categoryFilter) return false;
      if (!qNorm) return true;
      return `${p.name} ${p.color} ${p.category} ${p.subStyle} ${p.gsm} ${p.description}`
        .toLowerCase()
        .includes(qNorm);
    }).sort((a, b) =>
      sortBy === 'low' ? a.price - b.price : sortBy === 'high' ? b.price - a.price : a.position - b.position
    );
  }, [qNorm, categoryFilter, sortBy]);

  const matchedCollections = useMemo(() => {
    if (!qNorm) return COLLECTIONS;
    return COLLECTIONS.filter((c) =>
      `${c.title} ${c.subtitle} ${c.description}`.toLowerCase().includes(qNorm)
    );
  }, [qNorm]);

  const matchedHelp = useMemo(() => {
    if (!qNorm) return FAQ_ITEMS.slice(0, 4);
    return FAQ_ITEMS.filter((f) =>
      `${f.question} ${f.answer} ${f.category}`.toLowerCase().includes(qNorm)
    );
  }, [qNorm]);

  const handleSearchChange = (val: string) => {
    setQuery(val);
    if (val.trim()) setSearchParams({ q: val }, { replace: true });
    else setSearchParams({}, { replace: true });
  };

  return (
    <div className="page-shell">
      <nav className="breadcrumb-bar" aria-label="Breadcrumb">
        <Link to="/">Home</Link>
        <ChevronRight size={11} />
        <span>Search Catalogue</span>
      </nav>

      <header className="page-masthead">
        <p className="eyebrow">
          <i /> INSTANT STOREFRONT DISCOVERY
        </p>
        <h1 className="page-title !text-[clamp(44px,5.5vw,84px)]">
          SEARCH <span>YOUR CHOICE.</span>
        </h1>

        <div className="mt-6 max-w-3xl">
          <div className="flex items-center gap-3 border-b-2 border-[#18191a] pb-3">
            <Search size={22} className="text-[var(--blue)] shrink-0" />
            <input
              type="search"
              value={query}
              onChange={(e) => handleSearchChange(e.target.value)}
              placeholder="Search T-shirts, polo shirts, royal blue, 320 GSM, merino, sizing..."
              aria-label="Search storefront"
              className="w-full text-lg md:text-2xl font-medium bg-transparent outline-none"
            />
            {query && (
              <button
                type="button"
                onClick={() => handleSearchChange('')}
                aria-label="Clear search query"
                className="p-1 text-[#60675a] hover:text-[#18191a]"
              >
                <X size={18} />
              </button>
            )}
          </div>

          <div className="flex flex-wrap items-center gap-2 mt-4">
            <span className="mono text-[9px] text-[#60675a]">TRENDING EXPRESSIONS:</span>
            {['Royal Blue', 'Polo', 'Box Tee', 'Mock-Neck', 'Bomber', 'Merino', 'Oversized'].map(
              (term) => (
                <button
                  key={term}
                  type="button"
                  onClick={() => handleSearchChange(term)}
                  className={`px-2.5 py-1 text-[10px] font-mono border transition-colors ${
                    query.toLowerCase() === term.toLowerCase()
                      ? 'bg-[var(--blue)] text-white border-[var(--blue)]'
                      : 'border-[#cacdc4] bg-[#fafaf7] hover:border-[#18191a]'
                  }`}
                >
                  {term}
                </button>
              )
            )}
          </div>
        </div>
      </header>

      <div className="section-pad pt-8 space-y-10">
        {/* Result Scope Tabs + Product Refinements */}
        <div className="collection-toolbar">
          <div className="category-tabs">
            {[
              {
                id: 'all',
                label: 'All Results',
                count: matchedProducts.length + matchedCollections.length + matchedHelp.length,
              },
              { id: 'products', label: 'Products', count: matchedProducts.length },
              { id: 'collections', label: 'Collections', count: matchedCollections.length },
              { id: 'help', label: 'Care & FAQ', count: matchedHelp.length },
            ].map((t) => (
              <button
                key={t.id}
                type="button"
                onClick={() => setTab(t.id as typeof tab)}
                className={tab === t.id ? 'active' : ''}
              >
                {t.label} <sup>{String(t.count).padStart(2, '0')}</sup>
              </button>
            ))}
          </div>

          {(tab === 'all' || tab === 'products') && (
            <div className="flex flex-wrap items-center gap-4">
              <select
                aria-label="Filter category"
                value={categoryFilter}
                onChange={(e) => setCategoryFilter(e.target.value as typeof categoryFilter)}
                className="text-xs border border-[#c8cbc2] bg-[#fafaf7] px-3 py-1.5"
              >
                <option value="All">Category: All</option>
                <option value="T-Shirts">T-Shirts</option>
                <option value="Polo Shirts">Polo Shirts</option>
                <option value="Essentials">Essentials</option>
                <option value="Outerwear">Outerwear</option>
              </select>

              <label className="sort-label">
                <ArrowDownUp size={13} />
                <select
                  aria-label="Sort search results"
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value as typeof sortBy)}
                >
                  <option value="relevance">Relevance</option>
                  <option value="low">Price: Low to High</option>
                  <option value="high">Price: High to Low</option>
                </select>
              </label>
            </div>
          )}
        </div>

        {/* Matched Products */}
        {(tab === 'all' || tab === 'products') && (
          <section className="space-y-5">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-semibold tracking-tight">
                {qNorm ? `Matching Pieces for “${query}”` : 'Featured Catalogue Pieces'} (
                {matchedProducts.length})
              </h2>
              <Link to="/shop" className="text-link">
                Shop all products <ArrowUpRight size={13} />
              </Link>
            </div>

            {matchedProducts.length === 0 ? (
              <div className="editorial-card py-14 text-center space-y-4">
                <p className="mono text-xs text-[var(--blue)]">NO DIRECT GARMENT MATCH</p>
                <h3 className="text-2xl font-semibold">
                  Nothing matched &ldquo;{query}&rdquo; in {categoryFilter}.
                </h3>
                <p className="text-xs text-[#60675a] max-w-md mx-auto">
                  Try searching for broader silhouettes like &ldquo;Polo&rdquo;, &ldquo;Tee&rdquo;, &ldquo;Royal Blue&rdquo;, or explore our core collections below.
                </p>
                <div className="flex justify-center gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => {
                      handleSearchChange('');
                      setCategoryFilter('All');
                    }}
                    className="button button-blue"
                  >
                    Show All Pieces <RotateCcw size={15} />
                  </button>
                </div>
              </div>
            ) : (
              <div className="product-grid">
                {matchedProducts.map((p, idx) => (
                  <ProductCard key={p.id} product={p} index={idx} />
                ))}
              </div>
            )}
          </section>
        )}

        {/* Matched Collections */}
        {(tab === 'all' || tab === 'collections') && matchedCollections.length > 0 && (
          <section className="space-y-4 pt-4 border-t border-[var(--line)]">
            <h2 className="text-xl font-semibold tracking-tight">
              Collections ({matchedCollections.length})
            </h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
              {matchedCollections.map((col) => (
                <Link
                  key={col.slug}
                  to={`/collections/${col.slug}`}
                  className="editorial-card hover:border-[var(--blue)] transition-colors flex flex-col justify-between gap-4"
                >
                  <div>
                    <span className="mono text-[9px] text-[var(--blue)]">{col.code}</span>
                    <h3 className="text-lg font-semibold mt-1">{col.title}</h3>
                    <p className="text-xs text-[#60675a] mt-1.5 line-clamp-2">{col.subtitle}</p>
                  </div>
                  <span className="text-link self-start">
                    Open Collection <ArrowUpRight size={13} />
                  </span>
                </Link>
              ))}
            </div>
          </section>
        )}

        {/* Matched Help & FAQ */}
        {(tab === 'all' || tab === 'help') && matchedHelp.length > 0 && (
          <section className="space-y-4 pt-4 border-t border-[var(--line)]">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-semibold tracking-tight">
                Client Care &amp; Sizing Answers ({matchedHelp.length})
              </h2>
              <Link to="/faq" className="text-link">
                All FAQs <ArrowUpRight size={13} />
              </Link>
            </div>
            <div className="grid md:grid-cols-2 gap-4">
              {matchedHelp.map((f) => (
                <div key={f.id} className="editorial-card space-y-2">
                  <span className="mono text-[9px] text-[#60675a]">{f.category}</span>
                  <h3 className="text-sm font-semibold">{f.question}</h3>
                  <p className="text-xs text-[#5d6357] leading-relaxed">{f.answer}</p>
                </div>
              ))}
            </div>
          </section>
        )}
      </div>
    </div>
  );
}
