import { useEffect } from 'react';
import { BrowserRouter, Navigate, Route, Routes, Link, useLocation } from 'react-router-dom';
import { MotionConfig } from 'framer-motion';
import { ArrowRight, Compass } from 'lucide-react';
import { StoreProvider, useStore } from './context/StoreContext';
import { StorefrontLayout } from './components/Layout';
import { HomePage } from './pages/HomePage';
import {
  CollectionDetailsPage,
  PoloCollectionPage,
  SearchResultsPage,
  ShopAllPage,
  TShirtCollectionPage,
} from './pages/ShopPages';
import { ProductDetailsPage } from './pages/ProductDetailsPage';
import {
  CheckoutPage,
  OrderConfirmationPage,
  OrderTrackingPage,
  ShoppingBagPage,
  WishlistPage,
} from './pages/CommercePages';
import {
  ForgotPasswordPage,
  LoginPage,
  RegisterPage,
  ResetPasswordPage,
} from './pages/AuthPages';
import {
  AboutPage,
  ContactPage,
  FaqPage,
  SizeGuidePage,
} from './pages/BrandSupportPages';
import {
  PrivacyPolicyPage,
  ReturnsRefundsPage,
  ShippingDeliveryPage,
  TermsConditionsPage,
} from './pages/PolicyPages';

function ScrollAndTitleManager() {
  const { pathname, hash } = useLocation();

  useEffect(() => {
    if (hash) {
      const el = document.querySelector(hash);
      if (el) {
        el.scrollIntoView({ behavior: 'smooth' });
        return;
      }
    }
    window.scrollTo({ top: 0, left: 0, behavior: 'instant' as ScrollBehavior });
  }, [pathname, hash]);

  useEffect(() => {
    const map: Record<string, string> = {
      '/': 'YOUR CHOICE — Independent by Design',
      '/shop': 'Shop All Products — YOUR CHOICE',
      '/collections/t-shirts': 'T-Shirt Collection — YOUR CHOICE',
      '/collections/polo-shirts': 'Polo Shirt Collection — YOUR CHOICE',
      '/search': 'Search Catalogue — YOUR CHOICE',
      '/wishlist': 'Saved Wishlist — YOUR CHOICE',
      '/bag': 'Shopping Bag — YOUR CHOICE',
      '/checkout': 'Secure Checkout — YOUR CHOICE',
      '/order-confirmation': 'Order Confirmation — YOUR CHOICE',
      '/order-tracking': 'Order Tracking — YOUR CHOICE',
      '/login': 'Member Sign In — YOUR CHOICE',
      '/register': 'Create Account — YOUR CHOICE',
      '/forgot-password': 'Password Recovery — YOUR CHOICE',
      '/reset-password': 'Reset Password — YOUR CHOICE',
      '/about': 'About YOUR CHOICE — Always The Best Choice',
      '/contact': 'Contact Concierge — YOUR CHOICE',
      '/faq': 'FAQ — YOUR CHOICE',
      '/size-guide': 'Size Guide & Fit Finder — YOUR CHOICE',
      '/shipping-delivery': 'Shipping & Delivery — YOUR CHOICE',
      '/returns-refunds': 'Returns & Refunds — YOUR CHOICE',
      '/privacy-policy': 'Privacy Policy — YOUR CHOICE',
      '/terms-conditions': 'Terms & Conditions — YOUR CHOICE',
    };
    if (pathname.startsWith('/product/')) {
      document.title = 'Product Details — YOUR CHOICE';
    } else if (pathname.startsWith('/collections/')) {
      document.title = map[pathname] || 'Collection Details — YOUR CHOICE';
    } else if (pathname.startsWith('/order-confirmation/')) {
      document.title = 'Order Confirmed — YOUR CHOICE';
    } else {
      document.title = map[pathname] || 'YOUR CHOICE — Independent by Design';
    }
  }, [pathname]);

  return null;
}

function NotFoundPage() {
  const { setSitemapDrawerOpen } = useStore();
  return (
    <div className="page-shell section-pad pt-20">
      <div className="editorial-card py-20 text-center space-y-5 max-w-2xl mx-auto">
        <span className="mono text-xs text-[var(--blue)]">404 / UNCHARTED COORDINATE</span>
        <h1 className="display-condensed text-6xl">THIS ROUTE DOESN’T EXIST.</h1>
        <p className="text-xs text-[#60675a] max-w-md mx-auto">
          Return to the Vol. 01 Catalogue or open our Phase 01 Directory to jump directly to any of the 24 storefront pages.
        </p>
        <div className="flex flex-wrap justify-center gap-3 pt-2">
          <Link to="/shop" className="button button-blue">
            Explore All Products <ArrowRight size={16} />
          </Link>
          <button
            type="button"
            onClick={() => setSitemapDrawerOpen(true)}
            className="button button-outline"
          >
            Open 24-Page Directory <Compass size={15} />
          </button>
        </div>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <MotionConfig reducedMotion="user">
      <BrowserRouter>
        <StoreProvider>
          <ScrollAndTitleManager />
          <StorefrontLayout>
            <Routes>
              {/* 00. Reference Homepage */}
              <Route path="/" element={<HomePage />} />

              {/* 01. Shop / All Products */}
              <Route path="/shop" element={<ShopAllPage />} />
              <Route path="/products" element={<Navigate to="/shop" replace />} />

              {/* 02. T-Shirt Collection */}
              <Route path="/collections/t-shirts" element={<TShirtCollectionPage />} />
              <Route path="/t-shirts" element={<Navigate to="/collections/t-shirts" replace />} />

              {/* 03. Polo Shirt Collection */}
              <Route path="/collections/polo-shirts" element={<PoloCollectionPage />} />
              <Route
                path="/polo-shirts"
                element={<Navigate to="/collections/polo-shirts" replace />}
              />

              {/* 04. Collection Details */}
              <Route path="/collections" element={<CollectionDetailsPage />} />
              <Route path="/collections/:slug" element={<CollectionDetailsPage />} />
              <Route
                path="/collection-details"
                element={<Navigate to="/collections/expression-vol-01" replace />}
              />

              {/* 05. Product Details */}
              <Route path="/product/:slug" element={<ProductDetailsPage />} />
              <Route path="/product" element={<ProductDetailsPage />} />
              <Route path="/product-details" element={<ProductDetailsPage />} />

              {/* 06. Search Results */}
              <Route path="/search" element={<SearchResultsPage />} />

              {/* 07. Wishlist */}
              <Route path="/wishlist" element={<WishlistPage />} />

              {/* 08. Shopping Bag */}
              <Route path="/bag" element={<ShoppingBagPage />} />
              <Route path="/shopping-bag" element={<Navigate to="/bag" replace />} />
              <Route path="/cart" element={<Navigate to="/bag" replace />} />

              {/* 09. Checkout */}
              <Route path="/checkout" element={<CheckoutPage />} />

              {/* 10. Order Confirmation */}
              <Route path="/order-confirmation" element={<OrderConfirmationPage />} />
              <Route path="/order-confirmation/:orderId" element={<OrderConfirmationPage />} />

              {/* 11. Order Tracking */}
              <Route path="/order-tracking" element={<OrderTrackingPage />} />
              <Route path="/track-order" element={<Navigate to="/order-tracking" replace />} />

              {/* 12–15. Member Authentication Flows */}
              <Route path="/login" element={<LoginPage />} />
              <Route path="/register" element={<RegisterPage />} />
              <Route path="/registration" element={<Navigate to="/register" replace />} />
              <Route path="/forgot-password" element={<ForgotPasswordPage />} />
              <Route path="/reset-password" element={<ResetPasswordPage />} />

              {/* 16–19. Brand, Concierge, FAQ & Size Guide */}
              <Route path="/about" element={<AboutPage />} />
              <Route path="/contact" element={<ContactPage />} />
              <Route path="/faq" element={<FaqPage />} />
              <Route path="/size-guide" element={<SizeGuidePage />} />

              {/* 20–23. Storefront Policies */}
              <Route path="/shipping-delivery" element={<ShippingDeliveryPage />} />
              <Route path="/shipping" element={<Navigate to="/shipping-delivery" replace />} />
              <Route path="/returns-refunds" element={<ReturnsRefundsPage />} />
              <Route path="/returns" element={<Navigate to="/returns-refunds" replace />} />
              <Route path="/privacy-policy" element={<PrivacyPolicyPage />} />
              <Route path="/privacy" element={<Navigate to="/privacy-policy" replace />} />
              <Route path="/terms-conditions" element={<TermsConditionsPage />} />
              <Route path="/terms" element={<Navigate to="/terms-conditions" replace />} />

              {/* Fallback */}
              <Route path="*" element={<NotFoundPage />} />
            </Routes>
          </StorefrontLayout>
        </StoreProvider>
      </BrowserRouter>
    </MotionConfig>
  );
}
