import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Heart, Plus } from 'lucide-react';
import { Product, formatPrice } from '../data/catalog';
import { useStore } from '../context/StoreContext';

export function ProductCard({
  product,
  index = 0,
  showVariants = true,
}: {
  product: Product;
  index?: number;
  showVariants?: boolean;
}) {
  const { isWishlisted, toggleWishlist, addToBag } = useStore();
  const saved = isWishlisted(product.id);

  return (
    <motion.article
      className="product-card"
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay: Math.min(index * 0.06, 0.35) }}
    >
      <div className="product-image">
        <div className="product-meta">
          <span>{product.category}</span>
          {product.badge ? (
            <span
              className={`product-badge-pill ${
                product.badge.includes('Iconic') || product.badge.includes('New') ? 'is-blue' : ''
              }`}
            >
              {product.badge}
            </span>
          ) : (
            <span>{product.code}</span>
          )}
        </div>

        <Link
          to={`/product/${product.slug}`}
          className="block w-full h-full"
          aria-label={`Explore ${product.name} in ${product.color}`}
        >
          <img
            src={product.image}
            alt={`${product.name} in ${product.color}`}
            loading="lazy"
            width="700"
            height="700"
          />
        </Link>

        <button
          type="button"
          className={`product-wish-btn ${saved ? 'is-saved' : ''}`}
          aria-label={saved ? `Remove ${product.name} from wishlist` : `Save ${product.name} to wishlist`}
          aria-pressed={saved}
          onClick={(e) => {
            e.preventDefault();
            e.stopPropagation();
            toggleWishlist(product.id);
          }}
        >
          <Heart size={14} fill={saved ? 'currentColor' : 'none'} />
        </button>

        <button
          type="button"
          className="product-quick"
          aria-label={`Quick add ${product.name} size M`}
          onClick={(e) => {
            e.preventDefault();
            e.stopPropagation();
            const defaultSize = product.sizes.includes('L') ? 'L' : product.sizes[0];
            addToBag(product.id, defaultSize, 1, true);
          }}
        >
          <Plus size={17} />
          <span>Quick add · {product.sizes.includes('L') ? 'L' : product.sizes[0]}</span>
        </button>
      </div>

      <div className="product-label">
        <div>
          <h3>
            <Link to={`/product/${product.slug}`} className="hover:text-[var(--blue)] transition-colors">
              {product.name}
            </Link>
          </h3>
          <p>
            {product.color} · {product.fit}
          </p>
          {showVariants && product.variants.length > 1 && (
            <div className="product-swatches" aria-label="Available colorways">
              {product.variants.map((v) => (
                <Link
                  key={v.slug}
                  to={`/product/${v.slug}`}
                  title={v.label}
                  aria-label={`${product.name} in ${v.label}`}
                  className={`swatch-dot ${v.slug === product.slug ? 'is-active' : ''}`}
                  style={{ backgroundColor: v.hex }}
                />
              ))}
            </div>
          )}
        </div>
        <div className="text-right">
          <span className="font-mono text-[11px] font-medium">{formatPrice(product.price)}</span>
          {product.compareAtPrice && (
            <span className="block font-mono text-[9px] line-through text-[#8c9184]">
              {formatPrice(product.compareAtPrice)}
            </span>
          )}
        </div>
      </div>
    </motion.article>
  );
}
