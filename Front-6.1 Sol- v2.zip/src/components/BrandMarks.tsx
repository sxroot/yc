import React, { useState } from 'react';
import { motion, useReducedMotion } from 'framer-motion';
import { ArrowUpRight, LoaderCircle } from 'lucide-react';

export function Wordmark() {
  return (
    <span className="wordmark" aria-label="Your Choice">
      YOUR
      <span>
        CHOICE<sup>®</sup>
      </span>
    </span>
  );
}

export function OfficialEmblem({ className = 'w-12 h-8 object-contain' }: { className?: string }) {
  return (
    <img
      src="/images/official-emblem.webp"
      alt="YOUR CHOICE winged monogram emblem"
      className={className}
    />
  );
}

export function OfficialLogoLockup({ className = 'w-44 h-auto object-contain' }: { className?: string }) {
  return (
    <img
      src="/images/official-logo-transparent.webp"
      alt="YOUR CHOICE — Always The Best Choice official logo"
      className={className}
    />
  );
}

export function Reveal({
  children,
  className = '',
  delay = 0,
}: {
  children: React.ReactNode;
  className?: string;
  delay?: number;
}) {
  const reduced = useReducedMotion();
  return (
    <motion.div
      className={className}
      initial={reduced ? false : { opacity: 0, y: 32 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-40px' }}
      transition={{ duration: 0.75, delay, ease: [0.22, 1, 0.36, 1] }}
    >
      {children}
    </motion.div>
  );
}

export function SubscribeForm({ interest = 'newsletter' }: { interest?: string }) {
  const [email, setEmail] = useState('');
  const [feedback, setFeedback] = useState('');
  const [busy, setBusy] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim()) return;
    setBusy(true);
    setTimeout(() => {
      setBusy(false);
      setFeedback('You’re on the list. Make it yours.');
      setEmail('');
    }, 380);
  };

  return (
    <form className="subscribe" onSubmit={handleSubmit}>
      <label className="sr-only" htmlFor={`email-${interest}`}>
        Email address
      </label>
      <div className="email-field">
        <input
          id={`email-${interest}`}
          type="email"
          required
          maxLength={254}
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="Your email address"
          autoComplete="email"
          aria-describedby={`feedback-${interest}`}
        />
        <button type="submit" aria-label="Join the list" disabled={busy}>
          {busy ? <LoaderCircle className="spin" size={20} /> : <ArrowUpRight size={24} />}
        </button>
      </div>
      <p id={`feedback-${interest}`} className="form-feedback" role="status">
        {feedback || 'Only the good stuff. Unsubscribe whenever.'}
      </p>
    </form>
  );
}
