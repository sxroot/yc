export type CategoryType = 'T-Shirts' | 'Polo Shirts' | 'Essentials' | 'Outerwear';

export interface ColorVariantRef {
  label: string;
  hex: string;
  slug: string;
  image: string;
}

export interface Product {
  id: number;
  position: number;
  code: string;
  slug: string;
  name: string;
  category: CategoryType;
  subStyle: string;
  collectionSlugs: string[];
  price: number;
  compareAtPrice?: number;
  image: string;
  lifestyleImage: string;
  color: string;
  colorHex: string;
  variants: ColorVariantRef[];
  fit: 'Oversized' | 'Boxy' | 'Structured' | 'Relaxed';
  gsm: string;
  badge?: string;
  sizes: string[];
  lowStockSizes?: string[];
  description: string;
  editorialNote: string;
  material: string;
  care: string[];
  origin: string;
  modelNote: string;
  featuredHome?: boolean;
  bestsellerRank: number;
  isNew?: boolean;
}

export interface CollectionItem {
  slug: string;
  code: string;
  title: string;
  shortTitle: string;
  subtitle: string;
  heroImage: string;
  accentLabel: string;
  releaseDate: string;
  pieceCountLabel: string;
  description: string;
  essay: string[];
  specs: { label: string; value: string }[];
  featuredSlugs: string[];
}

export interface TrackingEvent {
  date: string;
  time: string;
  location: string;
  status: string;
  detail: string;
}

export interface OrderRecord {
  orderNumber: string;
  placedAt: string;
  estimatedDelivery: string;
  statusStep: 1 | 2 | 3 | 4 | 5; // 1 Confirmed, 2 Inspection, 3 Dispatched, 4 In Transit, 5 Delivered
  statusLabel: string;
  carrier: string;
  trackingCode: string;
  email: string;
  customerName: string;
  shippingAddress: {
    line1: string;
    line2?: string;
    city: string;
    postalCode: string;
    country: string;
  };
  shippingMethod: string;
  paymentSummary: string;
  subtotal: number;
  discount: number;
  shippingCost: number;
  packagingCost: number;
  total: number;
  giftNote?: string;
  items: {
    productId: number;
    slug: string;
    name: string;
    color: string;
    size: string;
    price: number;
    quantity: number;
    image: string;
  }[];
  events: TrackingEvent[];
}

export const formatPrice = (amount: number) =>
  new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    maximumFractionDigits: amount % 1 === 0 ? 0 : 2,
  }).format(amount);

export const PRODUCTS: Product[] = [
  {
    id: 1,
    position: 1,
    code: 'YC / 001',
    slug: 'expression-zip-hoodie',
    name: 'Expression Zip Hoodie',
    category: 'Essentials',
    subStyle: 'Heavyweight Fleece',
    collectionSlugs: ['expression-vol-01', 'outerwear-forms'],
    price: 88,
    image: '/images/hoodie.webp',
    lifestyleImage: '/images/campaign.webp',
    color: 'Charcoal',
    colorHex: '#1c1d20',
    variants: [
      { label: 'Charcoal', hex: '#1c1d20', slug: 'expression-zip-hoodie', image: '/images/hoodie.webp' },
      { label: 'Obsidian / Blue Tab', hex: '#11141c', slug: 'studio-heavy-fleece-hoodie', image: '/images/hoodie.webp' },
    ],
    fit: 'Oversized',
    gsm: '480 GSM Brushed Fleece',
    badge: 'Signature',
    sizes: ['XS', 'S', 'M', 'L', 'XL', 'XXL'],
    lowStockSizes: ['XS', 'XXL'],
    description:
      'A little structure. A lot of freedom. An oversized zip silhouette with dropped shoulders, a sculptural double-lined hood and a subtle royal blue micro-badge. Your everyday, expressed differently.',
    editorialNote:
      'Engineered to hold an architectural silhouette whether worn open over our 310 GSM Signature Tee or zipped high under technical outerwear.',
    material: '100% organic ring-spun cotton loopback fleece (480 GSM), custom two-way brushed YKK Excella metal zip, royal blue woven chest tab.',
    care: [
      'Cold gentle machine wash inside out (30°C max)',
      'Fasten zipper before washing to preserve placket alignment',
      'Reshape whilst damp and dry flat away from direct heat',
      'Cool iron on reverse; avoid ironing over micro-badge',
    ],
    origin: 'Cut & sewn in Porto, Portugal',
    modelNote: 'Model is 186cm / 6\'1" with 96cm chest and wears size L for an intended relaxed drape.',
    featuredHome: true,
    bestsellerRank: 1,
  },
  {
    id: 2,
    position: 2,
    code: 'YC / 002',
    slug: 'signature-blue-tee',
    name: 'Signature Blue Tee',
    category: 'T-Shirts',
    subStyle: 'Heavyweight Boxy',
    collectionSlugs: ['expression-vol-01', 't-shirts'],
    price: 42,
    image: '/images/tee.webp',
    lifestyleImage: '/images/collection-tees-hero.webp',
    color: 'Royal Blue',
    colorHex: '#2349ed',
    variants: [
      { label: 'Royal Blue', hex: '#2349ed', slug: 'signature-blue-tee', image: '/images/tee.webp' },
      { label: 'Jet Black', hex: '#18191b', slug: 'obsidian-box-tee', image: '/images/tee-black.webp' },
      { label: 'Warm Chalk', hex: '#edece6', slug: 'chalk-mock-neck-tee', image: '/images/tee-chalk.webp' },
      { label: 'Stone Olive', hex: '#555b4e', slug: 'mineral-garment-tee', image: '/images/tee-olive.webp' },
    ],
    fit: 'Oversized',
    gsm: '310 GSM Combed Jersey',
    badge: 'Iconic Color',
    sizes: ['XS', 'S', 'M', 'L', 'XL', 'XXL'],
    lowStockSizes: ['S'],
    description:
      'Loud in color. Quiet in detail. A considered oversized shape, a substantial 310 GSM hand feel and a custom YOUR CHOICE cobalt shade that refuses to blend in. No permission needed.',
    editorialNote:
      'Dyed to our bespoke Pantone-matched YC Royal (#2349ed) with enzyme bio-polishing for an ultra-clean matte surface and crisp sleeve break.',
    material: '100% long-staple combed organic cotton jersey (310 GSM), 28mm high-recovery ribbed crew collar, tonal twin-needle hems, silver micro-bar.',
    care: [
      'Wash cold (30°C) with similar saturated darks',
      'Do not tumble dry — air dry on wide-shoulder hanger',
      'Steam or cool iron inside out',
    ],
    origin: 'Knitted & garment-dyed in Barcelos, Portugal',
    modelNote: 'Model is 185cm / 6\'1" and wears size L. Take one size down for a closer standard fit.',
    featuredHome: true,
    bestsellerRank: 2,
  },
  {
    id: 3,
    position: 3,
    code: 'YC / 003',
    slug: 'silver-state-bomber',
    name: 'Silver State Bomber',
    category: 'Outerwear',
    subStyle: 'Sculptural Shell',
    collectionSlugs: ['expression-vol-01', 'outerwear-forms'],
    price: 145,
    image: '/images/jacket.webp',
    lifestyleImage: '/images/editorial.webp',
    color: 'Silver',
    colorHex: '#b4bac0',
    variants: [
      { label: 'Liquid Silver', hex: '#b4bac0', slug: 'silver-state-bomber', image: '/images/jacket.webp' },
      { label: 'Obsidian Matte', hex: '#191b1e', slug: 'matte-technical-overshirt', image: '/images/overshirt-black.webp' },
    ],
    fit: 'Relaxed',
    gsm: '240 GSM Technical Nylon',
    badge: 'Limited Vol. 01',
    sizes: ['XS', 'S', 'M', 'L', 'XL'],
    lowStockSizes: ['XS', 'XL'],
    description:
      'Change the light. Change the conversation. Sculptural articulated sleeves and a directional liquid-metallic finish meet a clean everyday silhouette. For wherever you choose to go next.',
    editorialNote:
      'Water-repellent Japanese nylon twill with light-reactive silver coating, contrasted against matte charcoal virgin-wool blend rib trims.',
    material: '100% Japanese water-repellent technical nylon shell, recycled breathable satin lining, internal welt pocket, two-way brushed metal zip.',
    care: [
      'Spot clean with damp microfibre cloth where possible',
      'Delicate cold cycle inside laundry bag if required',
      'Hang dry away from direct sunlight; do not iron shell directly',
    ],
    origin: 'Constructed in MilanStudio partner atelier',
    modelNote: 'Cropped at hip with generous sleeve volume. True to size.',
    featuredHome: true,
    bestsellerRank: 4,
  },
  {
    id: 4,
    position: 4,
    code: 'YC / 004',
    slug: 'atelier-pique-polo',
    name: 'Atelier Piqué Knit Polo',
    category: 'Polo Shirts',
    subStyle: 'Heavy Piqué',
    collectionSlugs: ['expression-vol-01', 'polo-shirts'],
    price: 74,
    image: '/images/polo-black.webp',
    lifestyleImage: '/images/collection-polos-hero.webp',
    color: 'Midnight Black',
    colorHex: '#15171a',
    variants: [
      { label: 'Midnight Black', hex: '#15171a', slug: 'atelier-pique-polo', image: '/images/polo-black.webp' },
      { label: 'Royal Blue', hex: '#2349ed', slug: 'royal-johnny-collar-polo', image: '/images/polo-blue.webp' },
      { label: 'Warm Chalk', hex: '#ecebe4', slug: 'alabaster-half-zip-polo', image: '/images/polo-chalk.webp' },
      { label: 'Stone Olive', hex: '#575d50', slug: 'mineral-waffle-polo', image: '/images/polo-olive.webp' },
    ],
    fit: 'Structured',
    gsm: '290 GSM Double Piqué',
    badge: 'Bestseller',
    sizes: ['XS', 'S', 'M', 'L', 'XL', 'XXL'],
    description:
      'Tailoring discipline meets subcultural ease. Knitted from crisp double-mercerized piqué with a concealed two-button placket, structured no-curl collar, and signature YC blue chest tab.',
    editorialNote:
      'Reimagines the classic polo without preppy clichés — sharper collar points, clean hem without side-vents, and architectural sleeve length.',
    material: '100% double-mercerized organic Supima cotton piqué (290 GSM), concealed placket with matte horn buttons, woven cobalt tab.',
    care: [
      'Cold gentle wash (30°C) buttoned up inside out',
      'Dry flat to maintain crisp collar architecture',
      'Warm steam on reverse',
    ],
    origin: 'Knitted in Guimarães, Portugal',
    modelNote: 'Structured modern fit — clean through the chest with slight boxy drape.',
    featuredHome: true,
    bestsellerRank: 3,
    isNew: true,
  },
  {
    id: 5,
    position: 5,
    code: 'YC / 005',
    slug: 'royal-johnny-collar-polo',
    name: 'Royal Tipped Johnny Polo',
    category: 'Polo Shirts',
    subStyle: 'Johnny Open-Collar',
    collectionSlugs: ['expression-vol-01', 'polo-shirts'],
    price: 78,
    image: '/images/polo-blue.webp',
    lifestyleImage: '/images/collection-polos-hero.webp',
    color: 'Royal Blue',
    colorHex: '#2349ed',
    variants: [
      { label: 'Royal Blue', hex: '#2349ed', slug: 'royal-johnny-collar-polo', image: '/images/polo-blue.webp' },
      { label: 'Midnight Black', hex: '#15171a', slug: 'atelier-pique-polo', image: '/images/polo-black.webp' },
      { label: 'Stone Olive', hex: '#575d50', slug: 'mineral-waffle-polo', image: '/images/polo-olive.webp' },
    ],
    fit: 'Structured',
    gsm: '14-Gauge Combed Knit',
    badge: 'New Vol. 01',
    sizes: ['XS', 'S', 'M', 'L', 'XL', 'XXL'],
    lowStockSizes: ['M'],
    description:
      'Buttonless conviction. A precision 14-gauge fine-knit open V-placket polo in electric YOUR CHOICE Royal Blue with crisp chalk collar tipping and ribbed waistband.',
    editorialNote:
      'Designed to transition effortlessly from gallery openings to late-evening studio sessions without losing its crisp knitted tension.',
    material: '85% combed organic cotton, 15% mulberry silk-touch modal (14-gauge Milano knit), contrast chalk collar intarsia, brushed silver chest bar.',
    care: [
      'Hand wash cold or wool/delicate cycle in mesh bag',
      'Never hang wet — dry flat on towel',
      'Light steam only',
    ],
    origin: 'Fully-fashioned knitwear, Northern Italy',
    modelNote: 'Hits cleanly at the hip bone thanks to the architectural rib hem.',
    bestsellerRank: 5,
    isNew: true,
  },
  {
    id: 6,
    position: 6,
    code: 'YC / 006',
    slug: 'obsidian-box-tee',
    name: 'Obsidian Heavyweight Box Tee',
    category: 'T-Shirts',
    subStyle: 'Heavyweight Boxy',
    collectionSlugs: ['expression-vol-01', 't-shirts'],
    price: 46,
    image: '/images/tee-black.webp',
    lifestyleImage: '/images/collection-tees-hero.webp',
    color: 'Jet Black',
    colorHex: '#18191b',
    variants: [
      { label: 'Jet Black', hex: '#18191b', slug: 'obsidian-box-tee', image: '/images/tee-black.webp' },
      { label: 'Royal Blue', hex: '#2349ed', slug: 'signature-blue-tee', image: '/images/tee.webp' },
      { label: 'Warm Chalk', hex: '#edece6', slug: 'chalk-mock-neck-tee', image: '/images/tee-chalk.webp' },
    ],
    fit: 'Boxy',
    gsm: '320 GSM Compact Cotton',
    badge: 'Core Uniform',
    sizes: ['XS', 'S', 'M', 'L', 'XL', 'XXL'],
    description:
      'Zero transparency. Maximum presence. Cut in a slightly cropped, wide-shoulder boxy block from 320 GSM compact-spun cotton that stands away from the body like outerwear.',
    editorialNote:
      'Reactive carbon-dyed so the black stays deep obsidian after fifty washes without fading to grey.',
    material: '100% organic compact-spun cotton (320 GSM), reinforced shoulder tape, 30mm ribbed collar, brushed silver minimal chest bar.',
    care: [
      'Machine wash cold inside out (30°C)',
      'Line dry in shade',
      'Warm iron on reverse',
    ],
    origin: 'Barcelos, Portugal',
    modelNote: 'Wide boxy chest with dropped elbow-grazing sleeves. True to size.',
    featuredHome: true,
    bestsellerRank: 6,
  },
  {
    id: 7,
    position: 7,
    code: 'YC / 007',
    slug: 'chalk-mock-neck-tee',
    name: 'Chalk Studio Mock-Neck Tee',
    category: 'T-Shirts',
    subStyle: 'Mock-Neck',
    collectionSlugs: ['t-shirts', 'expression-vol-01'],
    price: 48,
    image: '/images/tee-chalk.webp',
    lifestyleImage: '/images/collection-tees-hero.webp',
    color: 'Warm Chalk',
    colorHex: '#edece6',
    variants: [
      { label: 'Warm Chalk', hex: '#edece6', slug: 'chalk-mock-neck-tee', image: '/images/tee-chalk.webp' },
      { label: 'Royal Blue', hex: '#2349ed', slug: 'signature-blue-tee', image: '/images/tee.webp' },
      { label: 'Jet Black', hex: '#18191b', slug: 'obsidian-box-tee', image: '/images/tee-black.webp' },
    ],
    fit: 'Boxy',
    gsm: '300 GSM Interlock Jersey',
    badge: 'Editorial Pick',
    sizes: ['XS', 'S', 'M', 'L', 'XL', 'XXL'],
    description:
      'Unbleached warmth with gallery poise. An elevated 34mm high-stance mock-neck collar frames the collarbone cleanly under overshirts, blazers, and bombers.',
    editorialNote:
      'Our interlock double-knit eliminates the see-through issue common in off-white tees while feeling cool and silky against skin.',
    material: '100% organic double-knit interlock cotton (300 GSM), high-recovery 34mm mock-rib collar, signature royal blue micro-badge.',
    care: [
      'Wash cold separately with mild non-optical detergent',
      'Dry flat or hang on contoured hanger',
      'Steam to finish',
    ],
    origin: 'Barcelos, Portugal',
    modelNote: 'Relaxed studio block. True to size.',
    bestsellerRank: 7,
    isNew: true,
  },
  {
    id: 8,
    position: 8,
    code: 'YC / 008',
    slug: 'alabaster-half-zip-polo',
    name: 'Alabaster Merino Half-Zip Polo',
    category: 'Polo Shirts',
    subStyle: 'Half-Zip Knit',
    collectionSlugs: ['polo-shirts', 'expression-vol-01'],
    price: 86,
    image: '/images/polo-chalk.webp',
    lifestyleImage: '/images/collection-polos-hero.webp',
    color: 'Warm Chalk',
    colorHex: '#ecebe4',
    variants: [
      { label: 'Warm Chalk', hex: '#ecebe4', slug: 'alabaster-half-zip-polo', image: '/images/polo-chalk.webp' },
      { label: 'Slate Charcoal', hex: '#393d42', slug: 'slate-longsleeve-polo', image: '/images/polo-slate.webp' },
      { label: 'Midnight Black', hex: '#15171a', slug: 'atelier-pique-polo', image: '/images/polo-black.webp' },
    ],
    fit: 'Relaxed',
    gsm: '12-Gauge Cotton-Merino',
    badge: 'Atelier Series',
    sizes: ['XS', 'S', 'M', 'L', 'XL'],
    lowStockSizes: ['L', 'XL'],
    description:
      'Precision hardware meets tactile knitwear. A fine cotton-merino blend polo featuring a custom hairline-brushed silver zip placket and relaxed straight hem.',
    editorialNote:
      'Wear zipped to the collar for stark architectural minimalism or open to reveal collarbone layering.',
    material: '70% organic combed cotton, 30% extra-fine mulesing-free Australian merino wool, custom YKK Excella micro-zip.',
    care: [
      'Cold wool cycle inside mesh garment bag',
      'Dry flat away from heat sources',
      'Do not tumble dry',
    ],
    origin: 'Biella-spun yarn, knitted in Portugal',
    modelNote: 'Relaxed drape with softly dropped shoulder seam.',
    bestsellerRank: 8,
    isNew: true,
  },
  {
    id: 9,
    position: 9,
    code: 'YC / 009',
    slug: 'mineral-garment-tee',
    name: 'Mineral Garment-Dyed Tee',
    category: 'T-Shirts',
    subStyle: 'Oversized',
    collectionSlugs: ['t-shirts'],
    price: 45,
    image: '/images/tee-olive.webp',
    lifestyleImage: '/images/collection-tees-hero.webp',
    color: 'Stone Olive',
    colorHex: '#555b4e',
    variants: [
      { label: 'Stone Olive', hex: '#555b4e', slug: 'mineral-garment-tee', image: '/images/tee-olive.webp' },
      { label: 'Royal Blue', hex: '#2349ed', slug: 'signature-blue-tee', image: '/images/tee.webp' },
      { label: 'Jet Black', hex: '#18191b', slug: 'obsidian-box-tee', image: '/images/tee-black.webp' },
    ],
    fit: 'Oversized',
    gsm: '295 GSM Pigment Jersey',
    sizes: ['XS', 'S', 'M', 'L', 'XL', 'XXL'],
    description:
      'Subtle mineral depth. Garment-dyed in small vats using earth-mineral pigments so every seam develops a quiet, lived-in tonal character from day one.',
    editorialNote:
      'Pre-washed for zero shrinkage and an immediately broken-in hand feel that still holds a sharp shoulder line.',
    material: '100% organic carded cotton (295 GSM) for dry vintage texture, tonal woven chest micro-tab.',
    care: [
      'Wash cold inside out; pigment dye naturally evolves over time',
      'Air dry flat or hang',
    ],
    origin: 'Porto, Portugal',
    modelNote: 'Generous oversized block. Size down for regular fit.',
    bestsellerRank: 10,
  },
  {
    id: 10,
    position: 10,
    code: 'YC / 010',
    slug: 'slate-longsleeve-polo',
    name: 'Slate Architectural Long-Sleeve Polo',
    category: 'Polo Shirts',
    subStyle: 'Long-Sleeve Rugby',
    collectionSlugs: ['polo-shirts', 'outerwear-forms'],
    price: 84,
    image: '/images/polo-slate.webp',
    lifestyleImage: '/images/collection-polos-hero.webp',
    color: 'Slate Charcoal',
    colorHex: '#393d42',
    variants: [
      { label: 'Slate Charcoal', hex: '#393d42', slug: 'slate-longsleeve-polo', image: '/images/polo-slate.webp' },
      { label: 'Midnight Black', hex: '#15171a', slug: 'atelier-pique-polo', image: '/images/polo-black.webp' },
    ],
    fit: 'Relaxed',
    gsm: '330 GSM Heavy Jersey',
    sizes: ['XS', 'S', 'M', 'L', 'XL', 'XXL'],
    description:
      'Bridging shirting and sweatshirt weight. Cut from dense 330 GSM architectural jersey with a self-fabric tailored collar, concealed placket, and snug ribbed cuffs.',
    editorialNote:
      'Built as a standalone transitional piece for crisp mornings and air-conditioned creative studios.',
    material: '100% heavyweight organic cotton jersey (330 GSM), twill-taped collar stand, royal blue micro-tab.',
    care: [
      'Cold machine wash (30°C)',
      'Reshape collar while damp and air dry',
    ],
    origin: 'Guimarães, Portugal',
    modelNote: 'Relaxed fit through torso and sleeves.',
    bestsellerRank: 9,
  },
  {
    id: 11,
    position: 11,
    code: 'YC / 011',
    slug: 'cobalt-architectural-longsleeve',
    name: 'Cobalt Architectural Long-Sleeve Tee',
    category: 'T-Shirts',
    subStyle: 'Long-Sleeve',
    collectionSlugs: ['t-shirts', 'expression-vol-01'],
    price: 58,
    image: '/images/tee-longsleeve.webp',
    lifestyleImage: '/images/collection-tees-hero.webp',
    color: 'Cobalt Navy',
    colorHex: '#1f3368',
    variants: [
      { label: 'Cobalt Navy', hex: '#1f3368', slug: 'cobalt-architectural-longsleeve', image: '/images/tee-longsleeve.webp' },
      { label: 'Royal Blue', hex: '#2349ed', slug: 'signature-blue-tee', image: '/images/tee.webp' },
    ],
    fit: 'Oversized',
    gsm: '310 GSM Combed Cotton',
    badge: 'New Vol. 01',
    sizes: ['XS', 'S', 'M', 'L', 'XL', 'XXL'],
    description:
      'Longer lines. Deeper tone. Dropped shoulders flow into gathered architectural sleeves finished with deep 60mm cuffs and a structured crew neckline.',
    editorialNote:
      'Stacks effortlessly at the wrist and layers cleanly beneath short-sleeve boxy tees or technical vests.',
    material: '100% organic combed cotton (310 GSM), elastane-reinforced rib cuffs, brushed silver chest emblem.',
    care: [
      'Cold machine wash inside out',
      'Hang or flat dry',
    ],
    origin: 'Barcelos, Portugal',
    modelNote: 'Oversized silhouette. True to YOUR CHOICE sizing.',
    bestsellerRank: 11,
    isNew: true,
  },
  {
    id: 12,
    position: 12,
    code: 'YC / 012',
    slug: 'mineral-waffle-polo',
    name: 'Mineral Open-Collar Waffle Polo',
    category: 'Polo Shirts',
    subStyle: 'Johnny Open-Collar',
    collectionSlugs: ['polo-shirts'],
    price: 76,
    image: '/images/polo-olive.webp',
    lifestyleImage: '/images/collection-polos-hero.webp',
    color: 'Stone Olive',
    colorHex: '#575d50',
    variants: [
      { label: 'Stone Olive', hex: '#575d50', slug: 'mineral-waffle-polo', image: '/images/polo-olive.webp' },
      { label: 'Royal Blue', hex: '#2349ed', slug: 'royal-johnny-collar-polo', image: '/images/polo-blue.webp' },
      { label: 'Midnight Black', hex: '#15171a', slug: 'atelier-pique-polo', image: '/images/polo-black.webp' },
    ],
    fit: 'Boxy',
    gsm: '285 GSM Thermal Waffle',
    sizes: ['XS', 'S', 'M', 'L', 'XL'],
    lowStockSizes: ['XS'],
    description:
      'Three-dimensional texture in a calm architectural neutral. Micro-waffle piqué breathes naturally while giving monochrome outfits rich tactile contrast.',
    editorialNote:
      'Finished with a matte obsidian chest bar and split-hem side gussets so it drapes cleanly untucked.',
    material: '100% organic cotton micro-waffle knit (285 GSM), single-piece open Johnny collar.',
    care: [
      'Wash cold gentle cycle',
      'Dry flat to prevent vertical stretching',
    ],
    origin: 'Porto, Portugal',
    modelNote: 'Boxy cropped length designed to wear untucked.',
    bestsellerRank: 12,
  },
  {
    id: 13,
    position: 13,
    code: 'YC / 013',
    slug: 'matte-technical-overshirt',
    name: 'Matte Technical Zip Overshirt',
    category: 'Outerwear',
    subStyle: 'Structured Layer',
    collectionSlugs: ['outerwear-forms', 'expression-vol-01'],
    price: 128,
    compareAtPrice: 150,
    image: '/images/overshirt-black.webp',
    lifestyleImage: '/images/campaign.webp',
    color: 'Obsidian Black',
    colorHex: '#16181b',
    variants: [
      { label: 'Obsidian Black', hex: '#16181b', slug: 'matte-technical-overshirt', image: '/images/overshirt-black.webp' },
      { label: 'Liquid Silver', hex: '#b4bac0', slug: 'silver-state-bomber', image: '/images/jacket.webp' },
    ],
    fit: 'Structured',
    gsm: '265 GSM Stretch Twill',
    badge: 'Studio Utility',
    sizes: ['S', 'M', 'L', 'XL', 'XXL'],
    description:
      'Sharp utility without excess hardware. Concealed two-way metal zipper, architectural twin chest pockets, and a crisp point collar in water-resistant matte cotton-nylon.',
    editorialNote:
      'Pairs seamlessly over our Warm Chalk Mock-Neck Tee or Alabaster Half-Zip Polo as a modular three-season outer layer.',
    material: '68% organic cotton, 28% recycled polyamide, 4% elastane matte twill with PFC-free DWR finish.',
    care: [
      'Cold gentle wash closed',
      'Hang dry immediately; low iron if needed',
    ],
    origin: 'Constructed in Northern Portugal',
    modelNote: 'Boxy jacket block with room for knitwear underneath.',
    bestsellerRank: 13,
  },
  {
    id: 14,
    position: 14,
    code: 'YC / 014',
    slug: 'atelier-edition-blank-tee',
    name: 'Atelier 320GSM Creator Blank Tee',
    category: 'T-Shirts',
    subStyle: 'Oversized',
    collectionSlugs: ['t-shirts'],
    price: 44,
    image: '/images/tee-chalk.webp',
    lifestyleImage: '/images/collection-tees-hero.webp',
    color: 'Bone White',
    colorHex: '#f1f0ea',
    variants: [
      { label: 'Bone White', hex: '#f1f0ea', slug: 'atelier-edition-blank-tee', image: '/images/tee-chalk.webp' },
      { label: 'Jet Black', hex: '#18191b', slug: 'obsidian-box-tee', image: '/images/tee-black.webp' },
    ],
    fit: 'Oversized',
    gsm: '320 GSM Heavy Jersey',
    badge: 'Studio Blank',
    sizes: ['XS', 'S', 'M', 'L', 'XL', 'XXL'],
    description:
      'Start with a blank. Make something that isn’t. The foundational canvas developed for the YOUR CHOICE Design Studio — ultra-clean surface, zero outer branding on back, pure silhouette.',
    editorialNote:
      'Tightly spun single-jersey surface engineered both for pure minimalist wear and future Design Studio creator editions.',
    material: '100% GOTS-certified organic ring-spun cotton (320 GSM), tear-away internal studio spec label.',
    care: ['Machine wash cold (30°C)', 'Line dry'],
    origin: 'Barcelos, Portugal',
    modelNote: 'Signature oversized studio drape.',
    bestsellerRank: 14,
  },
  {
    id: 15,
    position: 15,
    code: 'YC / 015',
    slug: 'studio-heavy-fleece-hoodie',
    name: 'Studio Heavyweight Fleece Hoodie',
    category: 'Essentials',
    subStyle: 'Heavyweight Fleece',
    collectionSlugs: ['outerwear-forms'],
    price: 94,
    image: '/images/hoodie.webp',
    lifestyleImage: '/images/campaign.webp',
    color: 'Obsidian / Blue Tab',
    colorHex: '#11141c',
    variants: [
      { label: 'Obsidian / Blue Tab', hex: '#11141c', slug: 'studio-heavy-fleece-hoodie', image: '/images/hoodie.webp' },
      { label: 'Charcoal', hex: '#1c1d20', slug: 'expression-zip-hoodie', image: '/images/hoodie.webp' },
    ],
    fit: 'Oversized',
    gsm: '500 GSM Loopback',
    badge: 'Archive Heavy',
    sizes: ['S', 'M', 'L', 'XL', 'XXL'],
    lowStockSizes: ['S'],
    description:
      'Our heaviest 500 GSM fleece iteration. Double-layered hood with zero drawstrings, reinforced kangaroo pockets, and high-tension rib waist that creates a subtle blouson profile.',
    editorialNote:
      'Garment-washed with silicone-free enzymes for dry, sculptural volume that holds its shape year after year.',
    material: '100% organic heavyweight cotton fleece (500 GSM), two-way metal zip, cobalt woven studio tab.',
    care: ['Cold gentle wash inside out', 'Dry flat'],
    origin: 'Porto, Portugal',
    modelNote: 'Generous boxy torso with structured waist rib.',
    bestsellerRank: 15,
  },
];

export const COLLECTIONS: CollectionItem[] = [
  {
    slug: 'expression-vol-01',
    code: 'VOL. 01 / ARCHIVE 2026',
    title: 'The Expression Collection',
    shortTitle: 'Expression Vol. 01',
    subtitle: 'Not for everyone. For you. Considered silhouettes built for independent daily rotation.',
    heroImage: '/images/campaign.webp',
    accentLabel: 'FLAGSHIP CAPSULE — 08 PIECES',
    releaseDate: 'AUTUMN / WINTER 2026',
    pieceCountLabel: '08 CURATED PIECES',
    description:
      'Volume 01 establishes the foundational vocabulary of YOUR CHOICE: electric #2349ed Royal Blue punctuated against obsidian charcoal, warm chalk, and liquid technical silver.',
    essay: [
      'Uniforms usually ask you to disappear into a crowd. We set out to build the opposite: a modular wardrobe of architectural essentials that sharpen your presence without shouting for attention.',
      'Every piece in Volume 01 starts with fabric density and shoulder geometry — from 310 GSM compact-spun tees and double-mercerized piqué polos to articulated Japanese nylon outerwear.',
    ],
    specs: [
      { label: 'CHAPTER', value: '001 / UNRESTRICTED' },
      { label: 'PRIMARY WEIGHTS', value: '290 – 480 GSM ORGANIC' },
      { label: 'SIGNATURE PALETTE', value: 'YC ROYAL / OBSIDIAN / CHALK' },
      { label: 'ORIGIN', value: 'PORTUGAL & NORTHERN ITALY' },
    ],
    featuredSlugs: [
      'expression-zip-hoodie',
      'signature-blue-tee',
      'silver-state-bomber',
      'atelier-pique-polo',
      'royal-johnny-collar-polo',
      'obsidian-box-tee',
      'chalk-mock-neck-tee',
      'alabaster-half-zip-polo',
    ],
  },
  {
    slug: 't-shirts',
    code: 'CATEGORY 01 / JERSEY ARCHITECTURE',
    title: 'T-Shirt Collection',
    shortTitle: 'T-Shirts',
    subtitle: 'Heavyweight 295–320 GSM organic jersey engineered with high-recovery collars and sculptural drape.',
    heroImage: '/images/collection-tees-hero.webp',
    accentLabel: 'ARCHITECTURAL TEES — 06 SILHOUETTES',
    releaseDate: 'PERMANENT + SEASONAL EDITIONS',
    pieceCountLabel: '06 T-SHIRT EDITIONS',
    description:
      'A T-shirt shouldn’t collapse after three washes. Our T-Shirt Collection treats everyday jersey with outerwear discipline: compact-spun organic yarns, 28–34mm ribbed necklines, and precise shoulder drop.',
    essay: [
      'Whether worn solo in saturated YC Royal Blue or layered under knitwear in unbleached Warm Chalk, each silhouette is pattern-cut to create clean vertical lines and zero collar bacon.',
      'Choose between our Boxy Cropped block, Signature Oversized drape, elevated Mock-Neck interlock, or gathered-cuff Long-Sleeve.',
    ],
    specs: [
      { label: 'JERSEY DENSITY', value: '295 – 320 GSM COMBED' },
      { label: 'COLLAR RIB', value: '28MM – 34MM HIGH RECOVERY' },
      { label: 'SHRINKAGE CONTROL', value: 'PRE-SHRUNK ENZYME WASH' },
      { label: 'CERTIFICATION', value: '100% GOTS ORGANIC COTTON' },
    ],
    featuredSlugs: [
      'signature-blue-tee',
      'obsidian-box-tee',
      'chalk-mock-neck-tee',
      'mineral-garment-tee',
      'cobalt-architectural-longsleeve',
      'atelier-edition-blank-tee',
    ],
  },
  {
    slug: 'polo-shirts',
    code: 'CATEGORY 02 / ELEVATED KNIT & PIQUÉ',
    title: 'Polo Shirt Collection',
    shortTitle: 'Polo Shirts',
    subtitle: 'Sharp collars, concealed plackets, fine-gauge knits, and open Johnny necklines — stripped of country-club clichés.',
    heroImage: '/images/collection-polos-hero.webp',
    accentLabel: 'MODERN POLOS — 05 SILHOUETTES',
    releaseDate: 'ATELIER SERIES 2026',
    pieceCountLabel: '05 POLO EDITIONS',
    description:
      'The polo shirt, recalibrated for contemporary architecture and independent culture. No oversized crests — only tactile piqué, merino-cotton knits, brushed metal half-zips, and razor-clean proportions.',
    essay: [
      'We replaced flimsy single-piqué and curling collars with 290 GSM double-mercerized cotton, 14-gauge Milano knits, and three-dimensional thermal waffle weaves.',
      'Designed to pair effortlessly with wide pleated trousers, raw denim, or technical outerwear.',
    ],
    specs: [
      { label: 'CONSTRUCTIONS', value: 'DOUBLE PIQUÉ / 14G KNIT / WAFFLE' },
      { label: 'NECKLINES', value: 'CONCEALED / JOHNNY / HALF-ZIP' },
      { label: 'HARDWARE', value: 'YKK EXCELLA & MATTE HORN' },
      { label: 'FIT PROFILE', value: 'STRUCTURED MODERN DRAPE' },
    ],
    featuredSlugs: [
      'atelier-pique-polo',
      'royal-johnny-collar-polo',
      'alabaster-half-zip-polo',
      'slate-longsleeve-polo',
      'mineral-waffle-polo',
    ],
  },
  {
    slug: 'outerwear-forms',
    code: 'CATEGORY 03 / MODULAR LAYERS',
    title: 'Outerwear & Heavy Fleece',
    shortTitle: 'Outerwear & Layers',
    subtitle: 'Articulated shells, 500 GSM loopback hoodies, and matte technical overshirts built for changing light.',
    heroImage: '/images/editorial.webp',
    accentLabel: 'OUTERWEAR & FLEECE — 05 PIECES',
    releaseDate: 'VOL. 01 OUTER LAYER',
    pieceCountLabel: '05 LAYER PIECES',
    description:
      'Protective outer forms designed to frame our T-Shirt and Polo foundations. Engineered with two-way zippers so you control the silhouette proportion.',
    essay: [
      'From the light-reactive Silver State Bomber to our 500 GSM Studio Fleece, every outer layer balances tactile weight with clean minimal hardware.',
    ],
    specs: [
      { label: 'SHELLS', value: 'JAPANESE NYLON & DWR TWILL' },
      { label: 'FLEECE', value: '480 – 500 GSM LOOPBACK' },
      { label: 'CLOSURES', value: 'TWO-WAY BRUSHED METAL ZIPS' },
      { label: 'SEASONALITY', value: 'FOUR-SEASON MODULAR' },
    ],
    featuredSlugs: [
      'silver-state-bomber',
      'expression-zip-hoodie',
      'matte-technical-overshirt',
      'studio-heavy-fleece-hoodie',
      'slate-longsleeve-polo',
    ],
  },
];

export const SAMPLE_ORDERS: OrderRecord[] = [
  {
    orderNumber: 'YC-2026-8841',
    placedAt: '16 Nov 2026 · 14:18 UTC',
    estimatedDelivery: '19 – 20 Nov 2026',
    statusStep: 4,
    statusLabel: 'In Transit — Express Air Courier',
    carrier: 'DHL Express Carbon-Neutral',
    trackingCode: 'DHL-994820174-YC',
    email: 'member@yourchoice.studio',
    customerName: 'Alex Mercer',
    shippingAddress: {
      line1: '42 Redchurch Street, Studio 4B',
      city: 'London',
      postalCode: 'E2 7DP',
      country: 'United Kingdom',
    },
    shippingMethod: 'Express Air Courier (2–3 Business Days)',
    paymentSummary: 'Visa •••• 4242',
    subtotal: 204,
    discount: 0,
    shippingCost: 0,
    packagingCost: 0,
    total: 204,
    items: [
      {
        productId: 2,
        slug: 'signature-blue-tee',
        name: 'Signature Blue Tee',
        color: 'Royal Blue',
        size: 'L',
        price: 42,
        quantity: 1,
        image: '/images/tee.webp',
      },
      {
        productId: 4,
        slug: 'atelier-pique-polo',
        name: 'Atelier Piqué Knit Polo',
        color: 'Midnight Black',
        size: 'L',
        price: 74,
        quantity: 1,
        image: '/images/polo-black.webp',
      },
      {
        productId: 1,
        slug: 'expression-zip-hoodie',
        name: 'Expression Zip Hoodie',
        color: 'Charcoal',
        size: 'L',
        price: 88,
        quantity: 1,
        image: '/images/hoodie.webp',
      },
    ],
    events: [
      {
        date: '16 Nov 2026',
        time: '17:42 UTC',
        location: 'Leipzig Hub, DE',
        status: 'Departed European Air Hub',
        detail: 'Consignment sorted and loaded onto evening flight to London Stansted.',
      },
      {
        date: '16 Nov 2026',
        time: '11:15 UTC',
        location: 'Porto Atelier Hub, PT',
        status: 'Dispatched from Fulfilment Studio',
        detail: 'Archival garment box sealed and handed to DHL Express courier.',
      },
      {
        date: '15 Nov 2026',
        time: '18:30 UTC',
        location: 'Porto Atelier, PT',
        status: 'Quality & Measurement Verification Passed',
        detail: 'Each garment steamed, micro-badge inspected, and packed in recycled dust bag.',
      },
      {
        date: '15 Nov 2026',
        time: '14:18 UTC',
        location: 'YOUR CHOICE Digital Storefront',
        status: 'Order Confirmed',
        detail: 'Order YC-2026-8841 received and allocated from Vol. 01 studio stock.',
      },
    ],
  },
  {
    orderNumber: 'YC-2026-7419',
    placedAt: '14 Nov 2026 · 09:05 UTC',
    estimatedDelivery: 'Today before 19:00',
    statusStep: 4,
    statusLabel: 'Out for Delivery with Local Courier',
    carrier: 'UPS Premier Studio Direct',
    trackingCode: '1Z999YC84029184',
    email: 'sora.takahashi@studio.jp',
    customerName: 'Sora Takahashi',
    shippingAddress: {
      line1: '148 Mercer Street, Floor 3',
      city: 'New York, NY',
      postalCode: '10012',
      country: 'United States',
    },
    shippingMethod: 'Priority Express Air',
    paymentSummary: 'Apple Pay •••• 8819',
    subtotal: 223,
    discount: 22,
    shippingCost: 0,
    packagingCost: 8,
    total: 209,
    giftNote: 'Wear it your way. — S.',
    items: [
      {
        productId: 5,
        slug: 'royal-johnny-collar-polo',
        name: 'Royal Tipped Johnny Polo',
        color: 'Royal Blue',
        size: 'M',
        price: 78,
        quantity: 1,
        image: '/images/polo-blue.webp',
      },
      {
        productId: 3,
        slug: 'silver-state-bomber',
        name: 'Silver State Bomber',
        color: 'Silver',
        size: 'M',
        price: 145,
        quantity: 1,
        image: '/images/jacket.webp',
      },
    ],
    events: [
      {
        date: '16 Nov 2026',
        time: '08:24 EST',
        location: 'Manhattan South Depot, NY',
        status: 'Out for Delivery',
        detail: 'With courier vehicle #NY-14 · Signature required upon arrival.',
      },
      {
        date: '15 Nov 2026',
        time: '21:10 EST',
        location: 'Newark International Gateway, NJ',
        status: 'Customs Cleared',
        detail: 'Import duties pre-cleared (DDP) — zero fees due on delivery.',
      },
      {
        date: '14 Nov 2026',
        time: '16:00 UTC',
        location: 'Porto Atelier, PT',
        status: 'Dispatched in Collector Rigid Box',
        detail: 'Packed with custom gift note card.',
      },
    ],
  },
  {
    orderNumber: 'YC-2026-5092',
    placedAt: '06 Nov 2026 · 19:40 UTC',
    estimatedDelivery: 'Delivered 09 Nov 2026',
    statusStep: 5,
    statusLabel: 'Delivered — Signed by Recipient',
    carrier: 'DHL Express',
    trackingCode: 'DHL-552019482-YC',
    email: 'member@yourchoice.studio',
    customerName: 'Alex Mercer',
    shippingAddress: {
      line1: '42 Redchurch Street, Studio 4B',
      city: 'London',
      postalCode: 'E2 7DP',
      country: 'United Kingdom',
    },
    shippingMethod: 'Standard Tracked',
    paymentSummary: 'Mastercard •••• 9012',
    subtotal: 132,
    discount: 0,
    shippingCost: 0,
    packagingCost: 0,
    total: 132,
    items: [
      {
        productId: 6,
        slug: 'obsidian-box-tee',
        name: 'Obsidian Heavyweight Box Tee',
        color: 'Jet Black',
        size: 'L',
        price: 46,
        quantity: 1,
        image: '/images/tee-black.webp',
      },
      {
        productId: 8,
        slug: 'alabaster-half-zip-polo',
        name: 'Alabaster Merino Half-Zip Polo',
        color: 'Warm Chalk',
        size: 'L',
        price: 86,
        quantity: 1,
        image: '/images/polo-chalk.webp',
      },
    ],
    events: [
      {
        date: '09 Nov 2026',
        time: '13:12 UTC',
        location: 'London E2, UK',
        status: 'Delivered',
        detail: 'Received at studio reception — signed: A. MERCER.',
      },
      {
        date: '08 Nov 2026',
        time: '06:50 UTC',
        location: 'London Heathrow Sort Facility',
        status: 'Arrived in Destination Country',
        detail: 'Processed through UK gateway.',
      },
      {
        date: '06 Nov 2026',
        time: '19:40 UTC',
        location: 'YOUR CHOICE Storefront',
        status: 'Order Confirmed',
        detail: 'Order verified and released to studio warehouse.',
      },
    ],
  },
];

export interface FaqEntry {
  id: string;
  category:
    | 'Orders & Payment'
    | 'Sizing & Fit'
    | 'Products & Care'
    | 'Shipping & Delivery'
    | 'Returns & Refunds'
    | 'Design Studio';
  question: string;
  answer: string;
}

export const FAQ_ITEMS: FaqEntry[] = [
  {
    id: 'fit-1',
    category: 'Sizing & Fit',
    question: 'How do YOUR CHOICE T-shirts and Polo shirts fit compared to standard sizing?',
    answer:
      'Our T-shirts are pattern-cut in either our Signature Oversized block (dropped shoulder, relaxed chest) or Boxy Studio block (wide shoulder, clean hip-bone crop). Take your normal size for the intended editorial silhouette, or size down one size for a closer classic fit. Our Polo shirts use a Structured Modern block — true to size through the shoulders with a clean, un-clingy drape.',
  },
  {
    id: 'fit-2',
    category: 'Sizing & Fit',
    question: 'Will your 310–320 GSM cotton garments shrink after washing?',
    answer:
      'No. Every jersey, piqué, and loopback fleece garment undergoes an enzyme pre-shrinking bath before cutting. Provided you wash cold (30°C) and air dry away from tumble dryers, shrinkage is controlled within ±1%.',
  },
  {
    id: 'prod-1',
    category: 'Products & Care',
    question: 'What makes your Polo Shirt Collection different from traditional piqué polos?',
    answer:
      'Traditional polos often suffer from curling collar tips and thin, boxy sportswear cuts. We engineer ours in 290 GSM double-mercerized Supima piqué, 14-gauge fine Milano knit, and 285 GSM waffle — finished with high-density no-curl collars, concealed horn plackets or YKK Excella zips, and our minimal chest bar.',
  },
  {
    id: 'prod-2',
    category: 'Products & Care',
    question: 'How should I care for the Royal Blue (#2349ed) and Obsidian pieces?',
    answer:
      'Turn garments inside out and wash at 30°C with mild liquid detergent and similar dark tones. Avoid optical brighteners or bleach. Air dry flat or on a wide-contoured hanger and steam on reverse.',
  },
  {
    id: 'ord-1',
    category: 'Orders & Payment',
    question: 'Which payment methods and currencies are supported at checkout?',
    answer:
      'Our storefront checkout supports major credit and debit cards (Visa, Mastercard, American Express), Apple Pay, interest-free 4-part installments via Klarna, and Cash on Delivery in eligible metropolitan zones.',
  },
  {
    id: 'ord-2',
    category: 'Orders & Payment',
    question: 'Can I modify or cancel my order after placing it?',
    answer:
      'Orders enter studio inspection rapidly, so modifications to size or shipping address are open for 60 minutes after checkout. Contact our Client Concierge with your YC-2026 order number for immediate assistance.',
  },
  {
    id: 'ord-3',
    category: 'Orders & Payment',
    question: 'Do you offer archival gift packaging?',
    answer:
      'Yes. Every order arrives in recyclable matte dust bags as standard, or you can upgrade in your Shopping Bag (+$8) to our rigid matte-black YOUR CHOICE Collector Box with a custom printed card.',
  },
  {
    id: 'ship-1',
    category: 'Shipping & Delivery',
    question: 'How fast is shipping and when do I qualify for complimentary delivery?',
    answer:
      'Orders over $150 qualify automatically for complimentary Express Tracked Delivery worldwide. Orders placed before 14:00 UTC Monday–Friday dispatch the same business day from our studio hub, arriving in 1–3 business days via Express Air or 3–5 business days via Standard Tracked.',
  },
  {
    id: 'ship-2',
    category: 'Shipping & Delivery',
    question: 'Are customs duties and import taxes included for international orders?',
    answer:
      'Yes — we ship Delivered Duty Paid (DDP) across the United States, UK, European Union, Canada, Japan, Singapore, UAE, and Australia. The total shown at checkout is final, with no surprise courier fees at your door.',
  },
  {
    id: 'ret-1',
    category: 'Returns & Refunds',
    question: 'What is your return and size exchange policy?',
    answer:
      'You have 30 calendar days from delivery to initiate a return or complimentary instant size exchange. Pieces must be unworn, unwashed, and retain their original micro-tags and studio garment bag.',
  },
  {
    id: 'ret-2',
    category: 'Returns & Refunds',
    question: 'How quickly are refunds processed?',
    answer:
      'Once your parcel is scanned by the return courier, size exchanges ship immediately. Refunds are released within 48 business hours of studio quality verification back to your original payment method.',
  },
  {
    id: 'studio-1',
    category: 'Design Studio',
    question: 'What is the YOUR CHOICE Design Studio ("Design it. Wear it. Earn from it.")?',
    answer:
      'Design Studio is our upcoming creator ecosystem built on top of our 320 GSM Atelier Blanks and Piqué silhouettes — enabling independent artists and designers to publish limited editions, wear their own vision, and earn royalties on every piece sold without managing inventory.',
  },
];

export interface SizeChartCategory {
  key: 't-shirts' | 'polo-shirts' | 'hoodies' | 'outerwear';
  label: string;
  fitSummary: string;
  rowsCm: {
    size: string;
    chest: number;
    shoulder: number;
    length: number;
    sleeve: number;
  }[];
}

export const SIZE_CHARTS: SizeChartCategory[] = [
  {
    key: 't-shirts',
    label: 'T-Shirts (Oversized & Boxy)',
    fitSummary: 'Cut generously across the chest and shoulder with elbow-grazing sleeves. Size down one size for a closer classic drape.',
    rowsCm: [
      { size: 'XS', chest: 108, shoulder: 51, length: 67, sleeve: 21.5 },
      { size: 'S', chest: 114, shoulder: 53, length: 69.5, sleeve: 22.5 },
      { size: 'M', chest: 120, shoulder: 55, length: 72, sleeve: 23.5 },
      { size: 'L', chest: 126, shoulder: 57, length: 74.5, sleeve: 24.5 },
      { size: 'XL', chest: 132, shoulder: 59, length: 77, sleeve: 25.5 },
      { size: 'XXL', chest: 138, shoulder: 61, length: 79, sleeve: 26.5 },
    ],
  },
  {
    key: 'polo-shirts',
    label: 'Polo Shirts (Structured Modern)',
    fitSummary: 'Tailored through the collar and shoulder with a clean, straight modern torso designed to wear effortlessly untucked or tucked.',
    rowsCm: [
      { size: 'XS', chest: 102, shoulder: 45.5, length: 65.5, sleeve: 22 },
      { size: 'S', chest: 107, shoulder: 47, length: 67.5, sleeve: 23 },
      { size: 'M', chest: 112, shoulder: 48.5, length: 69.5, sleeve: 24 },
      { size: 'L', chest: 118, shoulder: 50.5, length: 71.5, sleeve: 25 },
      { size: 'XL', chest: 124, shoulder: 52.5, length: 73.5, sleeve: 26 },
      { size: 'XXL', chest: 130, shoulder: 54.5, length: 75.5, sleeve: 27 },
    ],
  },
  {
    key: 'hoodies',
    label: 'Hoodies & Heavy Fleece',
    fitSummary: '480–500 GSM sculptural fleece block with dropped shoulders and high-recovery waist rib.',
    rowsCm: [
      { size: 'XS', chest: 116, shoulder: 56, length: 65, sleeve: 59 },
      { size: 'S', chest: 122, shoulder: 58, length: 67.5, sleeve: 60.5 },
      { size: 'M', chest: 128, shoulder: 60, length: 70, sleeve: 62 },
      { size: 'L', chest: 134, shoulder: 62, length: 72.5, sleeve: 63.5 },
      { size: 'XL', chest: 140, shoulder: 64, length: 75, sleeve: 65 },
      { size: 'XXL', chest: 146, shoulder: 66, length: 77, sleeve: 66.5 },
    ],
  },
  {
    key: 'outerwear',
    label: 'Outerwear & Overshirts',
    fitSummary: 'Engineered with room to layer comfortably over 310 GSM tees or knitwear. True to size.',
    rowsCm: [
      { size: 'XS', chest: 118, shoulder: 51, length: 64, sleeve: 62 },
      { size: 'S', chest: 124, shoulder: 53, length: 66, sleeve: 63.5 },
      { size: 'M', chest: 130, shoulder: 55, length: 68.5, sleeve: 65 },
      { size: 'L', chest: 136, shoulder: 57, length: 71, sleeve: 66.5 },
      { size: 'XL', chest: 142, shoulder: 59, length: 73.5, sleeve: 68 },
      { size: 'XXL', chest: 148, shoulder: 61, length: 75.5, sleeve: 69.5 },
    ],
  },
];

export interface StorefrontRouteEntry {
  number: string;
  title: string;
  path: string;
  group: 'Catalogue & Discovery' | 'Bag & Checkout' | 'Member Account' | 'Brand, Fit & Policies';
  note: string;
}

export const STOREFRONT_PAGES: StorefrontRouteEntry[] = [
  { number: '00', title: 'Homepage (Reference Foundation)', path: '/', group: 'Catalogue & Discovery', note: 'Original hero, orbit, editorial shutter, scroll rail & studio' },
  { number: '01', title: 'Shop / All Products', path: '/shop', group: 'Catalogue & Discovery', note: 'Full 15-piece catalogue with multi-facet filters, sorting & density' },
  { number: '02', title: 'T-Shirt Collection', path: '/collections/t-shirts', group: 'Catalogue & Discovery', note: '295–320 GSM architectural jersey campaign & silhouette filters' },
  { number: '03', title: 'Polo Shirt Collection', path: '/collections/polo-shirts', group: 'Catalogue & Discovery', note: 'Double piqué, 14G knit, Johnny collar & half-zip polo showcase' },
  { number: '04', title: 'Collection Details', path: '/collections/expression-vol-01', group: 'Catalogue & Discovery', note: 'Editorial capsule essay, specs, lookbook & chapter switcher' },
  { number: '05', title: 'Product Details', path: '/product/signature-blue-tee', group: 'Catalogue & Discovery', note: 'Multi-angle zoom gallery, variants, size guide modal & accordions' },
  { number: '06', title: 'Search Results', path: '/search?q=blue', group: 'Catalogue & Discovery', note: 'Live search across products, collections & client care' },
  { number: '07', title: 'Wishlist', path: '/wishlist', group: 'Bag & Checkout', note: 'Saved wardrobe board with inline size selection & move-to-bag' },
  { number: '08', title: 'Shopping Bag', path: '/bag', group: 'Bag & Checkout', note: 'Full bag editor, free-shipping meter, collector box & promo codes' },
  { number: '09', title: 'Checkout', path: '/checkout', group: 'Bag & Checkout', note: 'Contact, shipping method, payment options & order creation' },
  { number: '10', title: 'Order Confirmation', path: '/order-confirmation', group: 'Bag & Checkout', note: 'Confirmed receipt with crest, item manifest & tracking link' },
  { number: '11', title: 'Order Tracking', path: '/order-tracking', group: 'Bag & Checkout', note: '5-stage visual milestone stepper & live carrier telemetry log' },
  { number: '12', title: 'Login', path: '/login', group: 'Member Account', note: 'Split-screen member sign-in + interactive member dashboard' },
  { number: '13', title: 'Registration', path: '/register', group: 'Member Account', note: 'Inner Circle registration with password strength & fit profile' },
  { number: '14', title: 'Forgot Password', path: '/forgot-password', group: 'Member Account', note: 'Account recovery request with instant reset simulation link' },
  { number: '15', title: 'Reset Password', path: '/reset-password', group: 'Member Account', note: 'New password setup with live security validation checklist' },
  { number: '16', title: 'About YOUR CHOICE', path: '/about', group: 'Brand, Fit & Policies', note: 'Official winged crest anatomy, manifesto, craft & three pillars' },
  { number: '17', title: 'Contact Concierge', path: '/contact', group: 'Brand, Fit & Policies', note: 'Topic-routed inquiry form with ticket ID & global studio hubs' },
  { number: '18', title: 'FAQ', path: '/faq', group: 'Brand, Fit & Policies', note: 'Searchable, category-filtered editorial accordions' },
  { number: '19', title: 'Size Guide', path: '/size-guide', group: 'Brand, Fit & Policies', note: 'CM/IN measurement tables, schematic & interactive Fit Finder' },
  { number: '20', title: 'Shipping & Delivery', path: '/shipping-delivery', group: 'Brand, Fit & Policies', note: 'Interactive global zone rates, DDP customs & dispatch SLA' },
  { number: '21', title: 'Returns & Refunds', path: '/returns-refunds', group: 'Brand, Fit & Policies', note: '30-day promise, 4-step journey & self-service RMA simulator' },
  { number: '22', title: 'Privacy Policy', path: '/privacy-policy', group: 'Brand, Fit & Policies', note: 'Editorial legal clauses + interactive Cookie Preferences panel' },
  { number: '23', title: 'Terms & Conditions', path: '/terms-conditions', group: 'Brand, Fit & Policies', note: 'Storefront, IP/trademark & creator terms with sticky TOC' },
];
