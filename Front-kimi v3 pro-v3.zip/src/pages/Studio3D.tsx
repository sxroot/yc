import React, { useEffect, useRef, useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { AnimatePresence, motion, useReducedMotion } from 'framer-motion';
import {
  ArrowLeft, ArrowRight, ArrowUpRight, Box, Camera, Check, ChevronDown, Circle, Download, Eye,
  Focus, Grid3X3, Image, Layers, Maximize, Minus, Move3D, Pause, Play, Plus, Rotate3D, RotateCcw,
  Save, Shirt, ShoppingBag, Sparkles, Sun, X, ZoomIn, ZoomOut,
} from 'lucide-react';
import { MARKETPLACE_DESIGNS, STUDIO_PRODUCTS } from '../data/phase2';
import { GarmentIllustration } from '../components/Phase2UI';
import { Wordmark } from '../components/BrandMarks';
import { useEcosystem } from '../context/EcosystemContext';
import { useStore } from '../context/StoreContext';

const ARTWORK=['/art/chrome-wings.png','/art/cobalt-bloom.png','/art/solar-eclipse.png','/art/signal-terrain.png'];
type CameraView='front'|'right'|'back'|'left';

export default function Studio3DPage(){
  const [params]=useSearchParams();
  const initialDesign=MARKETPLACE_DESIGNS.find((d)=>d.slug===params.get('design'));
  const initialProduct=Number(params.get('product'))||initialDesign?.productId||2;
  const [productId,setProductId]=useState(initialProduct);
  const product=STUDIO_PRODUCTS.find((p)=>p.id===productId)||STUDIO_PRODUCTS[0];
  const [color,setColor]=useState(params.get('color')||initialDesign?.garmentColor||product.colors[0]);
  const [artwork,setArtwork]=useState(initialDesign?.artwork||ARTWORK[3]);
  const [artScale,setArtScale]=useState(initialDesign?.placement.scale||.9);
  const [artY,setArtY]=useState(initialDesign?.placement.y||185);
  const [artRotation,setArtRotation]=useState(initialDesign?.placement.rotation||0);
  const [artOpacity,setArtOpacity]=useState(100);
  const [yaw,setYaw]=useState(0);
  const [zoom,setZoom]=useState(1);
  const [autoRotate,setAutoRotate]=useState(false);
  const [lighting,setLighting]=useState('Studio softbox');
  const [material,setMaterial]=useState('Organic jersey');
  const [roughness,setRoughness]=useState(72);
  const [grid,setGrid]=useState(true);
  const [presentation,setPresentation]=useState(false);
  const [size,setSize]=useState('L');
  const [savedId,setSavedId]=useState(`spatial-${Date.now()}`);
  const [saved,setSaved]=useState(false);
  const {saveStudioDesign}=useEcosystem();
  const {showToast,addToBag}=useStore();
  const navigate=useNavigate();
  const reduced=useReducedMotion();
  const stageRef=useRef<HTMLDivElement>(null);
  const dragRef=useRef<{x:number;yaw:number}|null>(null);
  const normalized=((yaw%360)+360)%360;
  const view:CameraView=(['front','right','back','left'] as const)[Math.round(normalized/90)%4];
  const residual=((normalized+45)%90)-45;
  const placement={x:210,y:artY,scale:artScale,rotation:artRotation};

  useEffect(()=>{if(!autoRotate||reduced)return;const timer=window.setInterval(()=>setYaw((value)=>value+1.2),40);return()=>clearInterval(timer);},[autoRotate,reduced]);
  const selectProduct=(id:number)=>{const next=STUDIO_PRODUCTS.find((p)=>p.id===id)!;setProductId(id);setColor(next.colors[0]);setMaterial(next.type==='Hoodie'?'Brushed fleece':next.type==='Polo'?'Cotton piqué':'Organic jersey');setSaved(false);};
  const preset=(next:CameraView)=>{setAutoRotate(false);setYaw({front:0,right:90,back:180,left:270}[next]);};
  const resetCamera=()=>{setYaw(0);setZoom(1);setAutoRotate(false);};
  const save=()=>{saveStudioDesign({id:savedId,name:`${product.name} / Spatial study`,productName:product.name,productId,color,project:{type:'3d',productId,color,artwork,artScale,artY,artRotation,artOpacity,yaw,zoom,lighting,material,roughness}});setSaved(true);showToast('3D study saved to your design shelf.');};
  const snapshot=()=>{const svg=stageRef.current?.querySelector('.three-garment svg');if(!svg)return;const clone=svg.cloneNode(true) as SVGSVGElement;clone.setAttribute('xmlns','http://www.w3.org/2000/svg');clone.setAttribute('width','1200');clone.setAttribute('height','1400');const blob=new Blob([new XMLSerializer().serializeToString(clone)],{type:'image/svg+xml'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=`your-choice-${view}-spatial-study.svg`;a.click();URL.revokeObjectURL(url);showToast(`${view} view exported as SVG.`);};
  const pointerDown=(e:React.PointerEvent)=>{if((e.target as HTMLElement).closest('button'))return;dragRef.current={x:e.clientX,yaw};e.currentTarget.setPointerCapture(e.pointerId);setAutoRotate(false);};
  const pointerMove=(e:React.PointerEvent)=>{if(!dragRef.current)return;setYaw(dragRef.current.yaw+(e.clientX-dragRef.current.x)*.65);};
  const materialSpec=material==='Brushed fleece'?{gsm:'480 GSM',hand:'Soft brushed interior',drape:'Sculptural / weighted',composition:'100% organic cotton fleece'}:material==='Cotton piqué'?{gsm:'280 GSM',hand:'Textured / breathable',drape:'Structured / open',composition:'100% organic cotton piqué'}:{gsm:'310 GSM',hand:'Dense / smooth',drape:'Relaxed / architectural',composition:'100% organic ring-spun cotton'};

  return <div className={`studio-workspace studio-3d-workspace ${presentation?'is-presenting':''}`}>
    <header className="studio-editor-header three-editor-header"><div className="editor-brand"><Link to="/studio"><Wordmark/></Link><span>3D<br/>STUDIO</span></div><div className="spatial-header-title"><Box size={16}/><span>SPATIAL GARMENT VIEWER</span><i/> LIVE PREVIEW</div><div className="editor-header-actions"><button onClick={snapshot}><Download size={16}/><span>Snapshot</span></button><button onClick={()=>setPresentation(!presentation)}>{presentation?<X size={16}/>:<Maximize size={16}/>}<span>{presentation?'Exit':'Present'}</span></button><button className="editor-save" onClick={save}><Save size={16}/><span>{saved?'Saved':'Save study'}</span></button></div></header>
    <div className="spatial-workspace-body">
      <aside className="spatial-left-panel"><div className="spatial-panel-heading"><span>Garment setup</span><small>01 / FOUNDATION</small></div><div className="spatial-panel-section"><label>Atelier blank</label><div className="spatial-product-select"><Shirt size={17}/><select value={productId} onChange={(e)=>selectProduct(Number(e.target.value))}>{STUDIO_PRODUCTS.map((item)=><option value={item.id} key={item.id}>{item.name}</option>)}</select><ChevronDown size={14}/></div><p>{product.fit}</p></div><div className="spatial-panel-section"><div className="spatial-label-row"><label>Garment colour</label><span>{color.toUpperCase()}</span></div><div className="spatial-color-grid">{product.colors.map((hex)=><button key={hex} className={color===hex?'active':''} style={{background:hex}} onClick={()=>{setColor(hex);setSaved(false);}} aria-label={`Garment colour ${hex}`}>{color===hex&&<Check size={14}/>}</button>)}</div><label className="spatial-custom-color">Custom dye preview<input type="color" value={color} onChange={(e)=>setColor(e.target.value)}/></label></div><div className="spatial-panel-section"><label>Material presentation</label><div className="material-options">{['Organic jersey','Cotton piqué','Brushed fleece'].map((item)=><button key={item} className={material===item?'active':''} onClick={()=>setMaterial(item)}><i className={`material-swatch ${item.replaceAll(' ','-')}`}/><span>{item}<small>{item==='Organic jersey'?'310 GSM':item==='Cotton piqué'?'280 GSM':'480 GSM'}</small></span>{material===item&&<Check size={13}/>}</button>)}</div><label className="spatial-range">Surface roughness <span>{roughness}%</span><input type="range" min="10" max="100" value={roughness} onChange={(e)=>setRoughness(Number(e.target.value))}/></label></div><div className="spatial-material-readout"><span>FABRIC INTELLIGENCE</span><dl><div><dt>Composition</dt><dd>{materialSpec.composition}</dd></div><div><dt>Hand feel</dt><dd>{materialSpec.hand}</dd></div><div><dt>Drape</dt><dd>{materialSpec.drape}</dd></div></dl></div></aside>
      <main ref={stageRef} className={`spatial-stage lighting-${lighting.toLowerCase().replaceAll(' ','-')} ${grid?'has-grid':''}`} onPointerDown={pointerDown} onPointerMove={pointerMove} onPointerUp={()=>{dragRef.current=null;}} onPointerCancel={()=>{dragRef.current=null;}}>
        <div className="spatial-stage-top"><div className="camera-presets">{(['front','right','back','left'] as const).map((item)=><button key={item} className={view===item?'active':''} onClick={()=>preset(item)}>{item==='front'?'Front':item==='back'?'Back':item==='left'?'Left side':'Right side'}</button>)}</div><div className="spatial-stage-status"><i/> REAL-TIME GARMENT PREVIEW</div></div>
        <div className="spatial-environment"><div className="spatial-horizon"/><div className="spatial-floor-grid"/><motion.div className="three-garment" key={`${productId}-${view}`} initial={{opacity:.65}} animate={{opacity:1}} transition={{duration:.2}} style={{transform:`perspective(1100px) rotateY(${residual}deg) scale(${zoom}) scaleX(${view==='left'||view==='right'?.68:1})`}}><div style={{opacity:artOpacity/100}}><GarmentIllustration color={color} artwork={artwork?artwork:undefined} placement={placement} productType={product.type} view={view==='back'?'back':'front'} material={material==='Organic jersey'?'jersey':'texture'}/></div></motion.div><div className="spatial-shadow" style={{transform:`translateX(-50%) scale(${zoom})`}}/></div>
        <div className="spatial-view-label"><span>{view.toUpperCase()} / {Math.round(normalized)}°</span><strong>{product.name}</strong><small>{materialSpec.gsm} · {material}</small></div>
        <div className="spatial-drag-hint"><Rotate3D size={17}/><span>DRAG TO ORBIT</span></div>
        <div className="spatial-camera-toolbar"><button onClick={()=>setAutoRotate(!autoRotate)} className={autoRotate?'active':''} title="Auto rotate">{autoRotate?<Pause size={17}/>:<Play size={17}/>}</button><i/><button onClick={()=>setZoom(Math.max(.6,zoom-.1))} title="Zoom out"><ZoomOut size={17}/></button><button className="spatial-zoom-value" onClick={()=>setZoom(1)}>{Math.round(zoom*100)}%</button><button onClick={()=>setZoom(Math.min(1.5,zoom+.1))} title="Zoom in"><ZoomIn size={17}/></button><i/><button onClick={resetCamera} title="Reset camera"><Focus size={17}/></button><button onClick={()=>setGrid(!grid)} className={grid?'active':''} title="Toggle environment grid"><Grid3X3 size={17}/></button></div>
        <div className="spatial-axis-gizmo"><span className="axis-y">Y</span><span className="axis-x">X</span><span className="axis-z">Z</span><i/></div>
      </main>
      <aside className="spatial-right-panel"><div className="spatial-panel-heading"><span>Artwork & scene</span><small>02 / EXPRESSION</small></div><div className="spatial-panel-section"><label>Artwork preview</label><div className="spatial-artwork-select"><button className={!artwork?'active':''} onClick={()=>setArtwork('')}><X size={18}/><span>None</span></button>{ARTWORK.map((art,i)=><button key={art} className={artwork===art?'active':''} onClick={()=>{setArtwork(art);setSaved(false);}}><img src={art} alt={`Artwork ${i+1}`}/>{artwork===art&&<i><Check size={11}/></i>}</button>)}</div></div><div className="spatial-panel-section"><span className="spatial-section-title"><Layers size={14}/> Design controls</span><label className="spatial-range">Artwork scale <span>{Math.round(artScale*100)}%</span><input type="range" min=".35" max="1.4" step=".01" value={artScale} onChange={(e)=>{setArtScale(Number(e.target.value));setSaved(false);}}/></label><label className="spatial-range">Vertical position <span>{Math.round(artY)}</span><input type="range" min="135" max="310" value={artY} onChange={(e)=>setArtY(Number(e.target.value))}/></label><label className="spatial-range">Rotation <span>{artRotation}°</span><input type="range" min="-30" max="30" value={artRotation} onChange={(e)=>setArtRotation(Number(e.target.value))}/></label><label className="spatial-range">Artwork opacity <span>{artOpacity}%</span><input type="range" min="10" max="100" value={artOpacity} onChange={(e)=>setArtOpacity(Number(e.target.value))}/></label><button className="spatial-reset-design" onClick={()=>{setArtScale(.9);setArtY(185);setArtRotation(0);setArtOpacity(100);}}><RotateCcw size={14}/> Reset artwork</button></div><div className="spatial-panel-section"><span className="spatial-section-title"><Sun size={14}/> Studio lighting</span><div className="lighting-options">{['Studio softbox','Clean daylight','After dark'].map((item)=><button key={item} className={lighting===item?'active':''} onClick={()=>setLighting(item)}><i className={`light-preview ${item.replaceAll(' ','-')}`}/><span>{item}</span></button>)}</div></div><div className="spatial-panel-section spatial-order-section"><label>Sample garment size</label><div className="size-select-row">{['S','M','L','XL'].map((item)=><button key={item} className={size===item?'active':''} onClick={()=>setSize(item)}>{item}</button>)}</div><button className="p2-button cyan full" onClick={()=>{save();addToBag(product.id,size,1,false);showToast(`${product.name} base in size ${size} added. Your spatial study is saved.`);navigate('/bag');}}><ShoppingBag size={16}/> Save & add base · ${product.price}</button><Link to={`/studio/2d?product=${product.id}&color=${encodeURIComponent(color)}`} className="spatial-2d-link">Refine in 2D Studio <ArrowUpRight size={14}/></Link></div></aside>
    </div>
    {presentation&&<button className="presentation-exit" onClick={()=>setPresentation(false)}><X size={16}/> Exit presentation</button>}
  </div>;
}
