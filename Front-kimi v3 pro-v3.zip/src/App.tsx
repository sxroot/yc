import { useEffect } from 'react';
import { BrowserRouter, Navigate, Route, Routes, Link, useLocation } from 'react-router-dom';
import { MotionConfig } from 'framer-motion';
import { ArrowRight, Compass } from 'lucide-react';
import { StoreProvider, useStore } from './context/StoreContext';
import { EcosystemProvider } from './context/EcosystemContext';
import { StorefrontLayout } from './components/Layout';
import { HomePage } from './pages/HomePage';
import { CollectionDetailsPage, PoloCollectionPage, SearchResultsPage, ShopAllPage, TShirtCollectionPage } from './pages/ShopPages';
import { ProductDetailsPage } from './pages/ProductDetailsPage';
import { CheckoutPage, OrderConfirmationPage, OrderTrackingPage, ShoppingBagPage, WishlistPage } from './pages/CommercePages';
import { ForgotPasswordPage, LoginPage, RegisterPage, ResetPasswordPage } from './pages/AuthPages';
import { AboutPage, ContactPage, FaqPage, SizeGuidePage } from './pages/BrandSupportPages';
import { PrivacyPolicyPage, ReturnsRefundsPage, ShippingDeliveryPage, TermsConditionsPage } from './pages/PolicyPages';
import { DashboardShell } from './components/Phase2UI';
import { AccountSettingsPage, AddressBookPage, CustomerOverviewPage, OrderDetailsPage, OrderHistoryPage, ProfilePage, SavedDesignsPage, AccountWishlistPage } from './pages/CustomerPages';
import { BecomeCreatorPage, CategoriesPage, CreatorProfilePage, DesignDetailsPage, ExploreDesignsPage, MarketplaceLandingPage, MarketplaceLayout } from './pages/MarketplacePages';
import { CreatorOverviewPage, CreatorProfileManagementPage, EarningsPage, MyDesignsPage, PayoutSettingsPage, PublishDesignPage, RewardsPage, SalesHistoryPage, SubmissionStatusPage } from './pages/CreatorPages';
import { StudioLandingPage, StudioModePage, StudioProductPage } from './pages/StudioPages';
import Studio2DPage from './pages/Studio2D';
import Studio3DPage from './pages/Studio3D';
import { PHASE2_PAGES } from './data/phase2';
import './App.css';

function ScrollAndTitleManager() {
  const { pathname, hash } = useLocation();
  useEffect(() => {
    if (hash) {
      const el = document.querySelector(hash);
      if (el) { el.scrollIntoView({ behavior: 'smooth' }); return; }
    }
    window.scrollTo({ top: 0, left: 0, behavior: 'instant' as ScrollBehavior });
  }, [pathname, hash]);
  useEffect(() => {
    const map: Record<string, string> = {
      '/': 'YOUR CHOICE \u2014 Independent by Design', '/shop': 'Shop All Products \u2014 YOUR CHOICE',
      '/collections/t-shirts': 'T-Shirt Collection \u2014 YOUR CHOICE', '/collections/polo-shirts': 'Polo Shirt Collection \u2014 YOUR CHOICE',
      '/search': 'Search Catalogue \u2014 YOUR CHOICE', '/wishlist': 'Saved Wishlist \u2014 YOUR CHOICE',
      '/bag': 'Shopping Bag \u2014 YOUR CHOICE', '/checkout': 'Secure Checkout \u2014 YOUR CHOICE',
      '/order-confirmation': 'Order Confirmation \u2014 YOUR CHOICE', '/order-tracking': 'Order Tracking \u2014 YOUR CHOICE',
      '/login': 'Member Sign In \u2014 YOUR CHOICE', '/register': 'Create Account \u2014 YOUR CHOICE',
      '/forgot-password': 'Password Recovery \u2014 YOUR CHOICE', '/reset-password': 'Reset Password \u2014 YOUR CHOICE',
      '/about': 'About YOUR CHOICE \u2014 Always The Best Choice', '/contact': 'Contact Concierge \u2014 YOUR CHOICE',
      '/faq': 'FAQ \u2014 YOUR CHOICE', '/size-guide': 'Size Guide & Fit Finder \u2014 YOUR CHOICE',
      '/shipping-delivery': 'Shipping & Delivery \u2014 YOUR CHOICE', '/returns-refunds': 'Returns & Refunds \u2014 YOUR CHOICE',
      '/privacy-policy': 'Privacy Policy \u2014 YOUR CHOICE', '/terms-conditions': 'Terms & Conditions \u2014 YOUR CHOICE',
    };
    const phase2 = PHASE2_PAGES.find((page) => page.path === pathname);
    if (phase2) document.title = `${phase2.title} \u2014 YOUR CHOICE`;
    else if (pathname.startsWith('/account/orders/')) document.title = 'Order Details \u2014 YOUR CHOICE';
    else if (pathname.startsWith('/marketplace/design/')) document.title = 'Design Details \u2014 YOUR CHOICE Marketplace';
    else if (pathname.startsWith('/marketplace/creator/')) document.title = 'Creator Profile \u2014 YOUR CHOICE Marketplace';
    else if (pathname.startsWith('/product/')) document.title = 'Product Details \u2014 YOUR CHOICE';
    else if (pathname.startsWith('/collections/')) document.title = map[pathname] || 'Collection Details \u2014 YOUR CHOICE';
    else if (pathname.startsWith('/order-confirmation/')) document.title = 'Order Confirmed \u2014 YOUR CHOICE';
    else document.title = map[pathname] || 'YOUR CHOICE \u2014 Independent by Design';
  }, [pathname]);
  return null;
}

function NotFoundPage() {
  const { setSitemapDrawerOpen } = useStore();
  return <div className="page-shell section-pad pt-20"><div className="editorial-card py-20 text-center space-y-5 max-w-2xl mx-auto"><span className="mono text-xs text-[var(--blue)]">404 / UNCHARTED COORDINATE</span><h1 className="display-condensed text-6xl">THIS ROUTE DOESN\u2019T EXIST.</h1><p className="text-xs text-[#60675a] max-w-md mx-auto">Return to the Vol. 01 Catalogue or open the complete ecosystem directory to jump directly to any storefront, marketplace, account or studio page.</p><div className="flex flex-wrap justify-center gap-3 pt-2"><Link to="/shop" className="button button-blue">Explore All Products <ArrowRight size={16} /></Link><button type="button" onClick={() => setSitemapDrawerOpen(true)} className="button button-outline">Open Ecosystem Directory <Compass size={15} /></button></div></div></div>;
}

export default function App() {
  return <MotionConfig reducedMotion="user"><BrowserRouter><StoreProvider><EcosystemProvider><ScrollAndTitleManager/><StorefrontLayout><Routes>
    <Route path="/" element={<HomePage/>}/>
    <Route path="/shop" element={<ShopAllPage/>}/><Route path="/products" element={<Navigate to="/shop" replace/>}/>
    <Route path="/collections/t-shirts" element={<TShirtCollectionPage/>}/><Route path="/t-shirts" element={<Navigate to="/collections/t-shirts" replace/>}/>
    <Route path="/collections/polo-shirts" element={<PoloCollectionPage/>}/><Route path="/polo-shirts" element={<Navigate to="/collections/polo-shirts" replace/>}/>
    <Route path="/collections" element={<CollectionDetailsPage/>}/><Route path="/collections/:slug" element={<CollectionDetailsPage/>}/><Route path="/collection-details" element={<Navigate to="/collections/expression-vol-01" replace/>}/>
    <Route path="/product/:slug" element={<ProductDetailsPage/>}/><Route path="/product" element={<ProductDetailsPage/>}/><Route path="/product-details" element={<ProductDetailsPage/>}/>
    <Route path="/search" element={<SearchResultsPage/>}/><Route path="/wishlist" element={<WishlistPage/>}/>
    <Route path="/bag" element={<ShoppingBagPage/>}/><Route path="/shopping-bag" element={<Navigate to="/bag" replace/>}/><Route path="/cart" element={<Navigate to="/bag" replace/>}/>
    <Route path="/checkout" element={<CheckoutPage/>}/><Route path="/order-confirmation" element={<OrderConfirmationPage/>}/><Route path="/order-confirmation/:orderId" element={<OrderConfirmationPage/>}/>
    <Route path="/order-tracking" element={<OrderTrackingPage/>}/><Route path="/track-order" element={<Navigate to="/order-tracking" replace/>}/>
    <Route path="/login" element={<LoginPage/>}/><Route path="/register" element={<RegisterPage/>}/><Route path="/registration" element={<Navigate to="/register" replace/>}/><Route path="/forgot-password" element={<ForgotPasswordPage/>}/><Route path="/reset-password" element={<ResetPasswordPage/>}/>
    <Route path="/about" element={<AboutPage/>}/><Route path="/contact" element={<ContactPage/>}/><Route path="/faq" element={<FaqPage/>}/><Route path="/size-guide" element={<SizeGuidePage/>}/>
    <Route path="/shipping-delivery" element={<ShippingDeliveryPage/>}/><Route path="/shipping" element={<Navigate to="/shipping-delivery" replace/>}/><Route path="/returns-refunds" element={<ReturnsRefundsPage/>}/><Route path="/returns" element={<Navigate to="/returns-refunds" replace/>}/><Route path="/privacy-policy" element={<PrivacyPolicyPage/>}/><Route path="/privacy" element={<Navigate to="/privacy-policy" replace/>}/><Route path="/terms-conditions" element={<TermsConditionsPage/>}/><Route path="/terms" element={<Navigate to="/terms-conditions" replace/>}/>

    {/* Phase 02 \u2014 Customer account product */}
    <Route path="/account" element={<DashboardShell type="customer"/>}><Route index element={<CustomerOverviewPage/>}/><Route path="profile" element={<ProfilePage/>}/><Route path="addresses" element={<AddressBookPage/>}/><Route path="orders" element={<OrderHistoryPage/>}/><Route path="orders/:orderId" element={<OrderDetailsPage/>}/><Route path="designs" element={<SavedDesignsPage/>}/><Route path="wishlist" element={<AccountWishlistPage/>}/><Route path="settings" element={<AccountSettingsPage/>}/></Route>
    <Route path="/dashboard" element={<Navigate to="/account" replace/>}/>

    {/* Phase 02 \u2014 Independent creator marketplace */}
    <Route path="/marketplace" element={<MarketplaceLayout/>}><Route index element={<MarketplaceLandingPage/>}/><Route path="explore" element={<ExploreDesignsPage/>}/><Route path="trending" element={<ExploreDesignsPage mode="trending"/>}/><Route path="featured" element={<ExploreDesignsPage/>}/><Route path="categories" element={<CategoriesPage/>}/><Route path="category/:slug" element={<ExploreDesignsPage/>}/><Route path="design/:slug" element={<DesignDetailsPage/>}/><Route path="creator/:handle" element={<CreatorProfilePage/>}/><Route path="become-creator" element={<BecomeCreatorPage/>}/></Route>
    <Route path="/become-creator" element={<Navigate to="/marketplace/become-creator" replace/>}/>

    {/* Phase 02 \u2014 Creator business workspace */}
    <Route path="/creator" element={<DashboardShell type="creator"/>}><Route index element={<CreatorOverviewPage/>}/><Route path="designs" element={<MyDesignsPage/>}/><Route path="publish" element={<PublishDesignPage/>}/><Route path="submissions" element={<SubmissionStatusPage/>}/><Route path="earnings" element={<EarningsPage/>}/><Route path="sales" element={<SalesHistoryPage/>}/><Route path="rewards" element={<RewardsPage/>}/><Route path="payout" element={<PayoutSettingsPage/>}/><Route path="profile" element={<CreatorProfileManagementPage/>}/></Route>
    <Route path="/creator-dashboard" element={<Navigate to="/creator" replace/>}/>

    {/* Phase 02 \u2014 Immersive 2D & 3D Design Studio */}
    <Route path="/studio" element={<StudioLandingPage/>}/><Route path="/studio/mode" element={<StudioModePage/>}/><Route path="/studio/products" element={<StudioProductPage/>}/><Route path="/studio/2d" element={<Studio2DPage/>}/><Route path="/studio/3d" element={<Studio3DPage/>}/>
    <Route path="/design-studio" element={<Navigate to="/studio" replace/>}/>
    <Route path="*" element={<NotFoundPage/>}/>
  </Routes></StorefrontLayout></EcosystemProvider></StoreProvider></BrowserRouter></MotionConfig>;
}
